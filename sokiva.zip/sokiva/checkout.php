<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

// Database connection
$host = 'localhost';
$dbname = 'sokiva';
$username = 'root';
$password = '';

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Check for errors
$error = '';
if (isset($_SESSION['checkout_error'])) {
    $error = $_SESSION['checkout_error'];
    unset($_SESSION['checkout_error']);
}

// Check if cart is empty
if (empty($_SESSION['cart'])) {
    header('Location: cart.php');
    exit;
}

// Get cart items
$cart_items = array();
$total = 0;

$ids = array_keys($_SESSION['cart']);
$placeholders = implode(',', array_fill(0, count($ids), '?'));
$stmt = $conn->prepare("SELECT * FROM products WHERE id IN ($placeholders)");
$stmt->execute($ids);
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($products as $product) {
    $qty = $_SESSION['cart'][$product['id']];
    $subtotal = $product['price'] * $qty;
    $cart_items[] = array(
        'product' => $product,
        'qty' => $qty,
        'subtotal' => $subtotal
    );
    $total += $subtotal;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - SOKIVA</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Baloo 2', sans-serif;
            background: #ffffff;
            color: #1a1a1a;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 1.5rem;
        }
        
        /* ===== HEADER ===== */
        .header {
            background: #ffffff;
            padding: 0.8rem 2rem;
            border-bottom: 1px solid #e5e7eb;
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        
        .header-container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        .logo {
            font-family: 'Baloo 2', sans-serif;
            font-weight: 800;
            font-size: 1.6rem;
            letter-spacing: 3px;
            color: #1a1a1a;
            text-transform: uppercase;
            text-decoration: none;
        }
        
        .logo span {
            color: #6b7280;
        }
        
        .tagline {
            color: #6b7280;
            font-size: 0.85rem;
            font-weight: 400;
            display: none;
        }
        
        @media (min-width: 768px) {
            .tagline {
                display: inline;
            }
        }
        
        .nav-menu {
            display: flex;
            align-items: center;
            gap: 2rem;
            list-style: none;
        }
        
        .nav-menu a {
            color: #333333;
            text-decoration: none;
            font-weight: 500;
            font-size: 1rem;
            transition: all 0.3s ease;
            position: relative;
        }
        
        .nav-menu a::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 0;
            height: 2px;
            background: #1a1a1a;
            transition: all 0.3s ease;
        }
        
        .nav-menu a:hover {
            color: #1a1a1a;
        }
        
        .nav-menu a:hover::after {
            width: 100%;
        }
        
        .nav-menu a.active {
            color: #1a1a1a;
            font-weight: 600;
        }
        
        .nav-menu a.active::after {
            width: 100%;
        }
        
        .cart-icon {
            position: relative;
            font-size: 1.2rem;
            color: #333333;
        }
        
        .cart-icon:hover {
            color: #1a1a1a;
        }
        
        .cart-badge {
            position: absolute;
            top: -8px;
            right: -10px;
            background: #1a1a1a;
            color: white;
            font-size: 0.65rem;
            font-weight: 700;
            width: 18px;
            height: 18px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .hamburger {
            display: none;
            flex-direction: column;
            gap: 5px;
            cursor: pointer;
            background: none;
            border: none;
            padding: 0.3rem;
        }
        
        .hamburger span {
            width: 25px;
            height: 3px;
            background: #1a1a1a;
            border-radius: 3px;
            transition: all 0.3s ease;
        }
        
        @media (max-width: 768px) {
            .hamburger {
                display: flex;
            }
            
            .nav-menu {
                display: none;
                flex-direction: column;
                width: 100%;
                padding: 1rem 0;
                border-top: 1px solid #e5e7eb;
                gap: 0.8rem;
            }
            
            .nav-menu.open {
                display: flex;
            }
            
            .nav-menu a {
                font-size: 1.1rem;
                padding: 0.5rem 0;
            }
        }
        
        /* ===== HERO ===== */
        .hero {
            background: #f8f8f8;
            padding: 2.5rem 2rem;
            text-align: center;
            border-bottom: 1px solid #e5e7eb;
            margin-bottom: 2rem;
        }
        
        .hero h1 {
            font-size: 2.2rem;
            font-weight: 800;
            letter-spacing: 1px;
            margin-bottom: 0.5rem;
            color: #1a1a1a;
        }
        
        .hero p {
            font-size: 1.1rem;
            font-weight: 400;
            color: #6b7280;
            max-width: 600px;
            margin: 0 auto;
        }
        
        @media (max-width: 768px) {
            .hero h1 {
                font-size: 1.8rem;
            }
        }
        
        /* ===== BUTTONS ===== */
        .btn {
            display: inline-block;
            padding: 0.7rem 1.8rem;
            border-radius: 8px;
            text-decoration: none;
            font-family: 'Baloo 2', sans-serif;
            font-weight: 600;
            font-size: 0.95rem;
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
            text-align: center;
        }
        
        .btn-primary {
            background: #1a1a1a;
            color: #ffffff;
        }
        
        .btn-primary:hover {
            background: #333333;
            transform: translateY(-2px);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
        }
        
        .btn-secondary {
            background: #ffffff;
            color: #1a1a1a;
            border: 1px solid #e5e7eb;
        }
        
        .btn-secondary:hover {
            background: #f8f8f8;
        }
        
        /* ===== CHECKOUT ===== */
        .checkout-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2rem;
            padding: 1rem 0 3rem;
        }
        
        .checkout-form {
            background: #ffffff;
            padding: 2rem;
            border-radius: 12px;
            border: 1px solid #e5e7eb;
        }
        
        .checkout-form h3 {
            font-weight: 700;
            font-size: 1.2rem;
            color: #1a1a1a;
            margin-bottom: 1.5rem;
            padding-bottom: 0.5rem;
            border-bottom: 2px solid #f8f8f8;
        }
        
        .form-group {
            margin-bottom: 1rem;
        }
        
        .form-group label {
            display: block;
            font-weight: 600;
            font-size: 0.9rem;
            color: #333333;
            margin-bottom: 0.3rem;
        }
        
        .form-group label .required {
            color: #dc2626;
        }
        
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 0.7rem 1rem;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            font-family: 'Baloo 2', sans-serif;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: #ffffff;
            color: #1a1a1a;
        }
        
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #1a1a1a;
            box-shadow: 0 0 0 3px rgba(0, 0, 0, 0.05);
        }
        
        .form-group textarea {
            resize: vertical;
            min-height: 80px;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }
        
        .order-summary {
            background: #ffffff;
            padding: 2rem;
            border-radius: 12px;
            border: 1px solid #e5e7eb;
            height: fit-content;
            position: sticky;
            top: 100px;
        }
        
        .order-summary h3 {
            font-weight: 700;
            font-size: 1.2rem;
            color: #1a1a1a;
            margin-bottom: 1.5rem;
            padding-bottom: 0.5rem;
            border-bottom: 2px solid #f8f8f8;
        }
        
        .order-item {
            display: flex;
            justify-content: space-between;
            padding: 0.5rem 0;
            border-bottom: 1px solid #f8f8f8;
            font-size: 0.95rem;
        }
        
        .order-item .item-name {
            color: #333333;
        }
        
        .order-item .item-price {
            font-weight: 600;
            color: #1a1a1a;
        }
        
        .order-total {
            display: flex;
            justify-content: space-between;
            padding: 1rem 0;
            border-top: 2px solid #e5e7eb;
            margin-top: 0.5rem;
            font-size: 1.3rem;
            font-weight: 700;
            color: #1a1a1a;
        }
        
        .order-total .amount {
            color: #1a1a1a;
        }
        
        .alert-error {
            background: #fee2e2;
            color: #991b1b;
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1rem;
            border: 1px solid #fecaca;
        }
        
        /* ===== FOOTER ===== */
        .footer {
            background: #f8f8f8;
            padding: 2.5rem 2rem 1.5rem;
            margin-top: 2rem;
            border-top: 1px solid #e5e7eb;
        }
        
        .footer-container {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 2rem;
        }
        
        .footer h4 {
            font-weight: 700;
            font-size: 1rem;
            margin-bottom: 0.8rem;
            color: #1a1a1a;
        }
        
        .footer ul {
            list-style: none;
        }
        
        .footer ul li {
            margin-bottom: 0.4rem;
        }
        
        .footer ul a {
            color: #6b7280;
            text-decoration: none;
            transition: all 0.3s ease;
            font-size: 0.9rem;
        }
        
        .footer ul a:hover {
            color: #1a1a1a;
        }
        
        .footer-bottom {
            text-align: center;
            padding-top: 1.5rem;
            margin-top: 1.5rem;
            border-top: 1px solid #e5e7eb;
            color: #9ca3af;
            font-size: 0.85rem;
        }
        
        .footer-logo {
            font-weight: 800;
            font-size: 1.3rem;
            letter-spacing: 3px;
            text-transform: uppercase;
            color: #1a1a1a;
        }
        
        .footer-logo span {
            color: #6b7280;
        }
        
        /* ===== WHATSAPP FLOAT ===== */
        .whatsapp-float {
            position: fixed;
            bottom: 30px;
            right: 30px;
            background: #25D366;
            color: white;
            width: 55px;
            height: 55px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            box-shadow: 0 4px 20px rgba(37, 211, 102, 0.3);
            transition: all 0.3s ease;
            z-index: 999;
            text-decoration: none;
        }
        
        .whatsapp-float:hover {
            transform: scale(1.1);
            box-shadow: 0 8px 30px rgba(37, 211, 102, 0.4);
        }
        
        /* ===== RESPONSIVE ===== */
        @media (max-width: 768px) {
            .checkout-grid {
                grid-template-columns: 1fr;
            }
            .form-row {
                grid-template-columns: 1fr;
            }
            .order-summary {
                position: relative;
                top: 0;
            }
        }
        
        @media (max-width: 576px) {
            .footer-container {
                grid-template-columns: 1fr;
                text-align: center;
            }
            .btn {
                padding: 0.5rem 1.2rem;
                font-size: 0.85rem;
            }
            .checkout-form {
                padding: 1.5rem;
            }
            .order-summary {
                padding: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <!-- ===== HEADER ===== -->
    <header class="header">
        <div class="header-container">
            <a href="/sokiva/" class="logo">SOKIVA <span>.</span></a>
            <span class="tagline">Access your desire.</span>
            
            <button class="hamburger" id="hamburger" aria-label="Toggle menu">
                <span></span>
                <span></span>
                <span></span>
            </button>
            
            <nav>
                <ul class="nav-menu" id="navMenu">
                    <li><a href="/sokiva/">Home</a></li>
                    <li><a href="/sokiva/shop.php">All Laptops</a></li>
                    <li><a href="/sokiva/contact.php">Contact</a></li>
                    <li>
                        <a href="/sokiva/cart.php" class="cart-icon">
                            <i class="fas fa-shopping-cart"></i>
                            <?php
                            $cart_count = isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0;
                            if ($cart_count > 0) {
                                echo '<span class="cart-badge">' . $cart_count . '</span>';
                            }
                            ?>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </header>
    
    <script>
        document.getElementById('hamburger').addEventListener('click', function() {
            document.getElementById('navMenu').classList.toggle('open');
        });
    </script>

    <!-- ===== HERO ===== -->
    <section class="hero">
        <div class="container">
            <h1>Checkout</h1>
            <p>Complete your order</p>
        </div>
    </section>

    <!-- ===== CHECKOUT ===== -->
    <main class="container">
        <div class="checkout-grid">
            <!-- Checkout Form -->
            <div class="checkout-form">
                <h3><i class="fas fa-address-card"></i> Delivery Information</h3>
                
                <?php if ($error): ?>
                <div class="alert-error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
                <?php endif; ?>
                
                <form action="place_order.php" method="POST" id="checkoutForm">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="first_name">First Name <span class="required">*</span></label>
                            <input type="text" id="first_name" name="first_name" placeholder="John" required>
                        </div>
                        <div class="form-group">
                            <label for="last_name">Last Name <span class="required">*</span></label>
                            <input type="text" id="last_name" name="last_name" placeholder="Doe" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email Address <span class="required">*</span></label>
                        <input type="email" id="email" name="email" placeholder="john@example.com" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="phone">Phone Number <span class="required">*</span></label>
                        <input type="tel" id="phone" name="phone" placeholder="0712345678" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="address">Delivery Address <span class="required">*</span></label>
                        <textarea id="address" name="address" placeholder="Enter your full delivery address" required></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="payment_method">Payment Method <span class="required">*</span></label>
                        <select id="payment_method" name="payment_method" required>
                            <option value="">Select payment method...</option>
                            <option value="mpesa">M-Pesa</option>
                            <option value="bank_transfer">Bank Transfer</option>
                            <option value="cash_on_delivery">Cash on Delivery</option>
                        </select>
                    </div>
                    
                    <button type="submit" class="btn btn-primary" style="width:100%; margin-top: 0.5rem;">
                        <i class="fas fa-check-circle"></i> Place Order
                    </button>
                </form>
            </div>
            
            <!-- Order Summary -->
            <div class="order-summary">
                <h3><i class="fas fa-shopping-bag"></i> Order Summary</h3>
                
                <?php foreach ($cart_items as $item): ?>
                <div class="order-item">
                    <span class="item-name"><?php echo htmlspecialchars($item['product']['name']); ?> x<?php echo $item['qty']; ?></span>
                    <span class="item-price">KES <?php echo number_format($item['subtotal']); ?></span>
                </div>
                <?php endforeach; ?>
                
                <div class="order-total">
                    <span>Total:</span>
                    <span class="amount">KES <?php echo number_format($total); ?></span>
                </div>
                
                <div style="margin-top: 1.5rem; padding-top: 1rem; border-top: 1px solid #e5e7eb;">
                    <a href="cart.php" class="btn btn-secondary" style="width:100%;">
                        <i class="fas fa-arrow-left"></i> Back to Cart
                    </a>
                </div>
            </div>
        </div>
    </main>

    <!-- ===== FOOTER ===== -->
    <footer class="footer">
        <div class="footer-container">
            <div>
                <div class="footer-logo">SOKIVA <span>.</span></div>
                <p style="margin-top: 0.3rem; color: #6b7280; font-size: 0.9rem;">Access your desire.</p>
            </div>
            <div>
                <h4>Quick Links</h4>
                <ul>
                    <li><a href="/sokiva/">Home</a></li>
                    <li><a href="/sokiva/shop.php">All Laptops</a></li>
                    <li><a href="/sokiva/contact.php">Contact</a></li>
                    <li><a href="/sokiva/about.php">About Us</a></li>
                </ul>
            </div>
            <div>
                <h4>Support</h4>
                <ul>
                    <li><a href="/sokiva/contact.php">Help Center</a></li>
                    <li><a href="/sokiva/privacy.php">Privacy Policy</a></li>
                    <li><a href="/sokiva/terms.php">Terms & Conditions</a></li>
                </ul>
            </div>
            <div>
                <h4>Connect With Us</h4>
                <ul>
                    <li><a href="https://wa.me/254793019606" target="_blank"><i class="fab fa-whatsapp"></i> WhatsApp</a></li>
                    <li><a href="#" target="_blank"><i class="fab fa-facebook"></i> Facebook</a></li>
                    <li><a href="#" target="_blank"><i class="fab fa-instagram"></i> Instagram</a></li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            &copy; <?php echo date('Y'); ?> SOKIVA. All rights reserved.
        </div>
    </footer>

    <!-- WhatsApp Float -->
    <a href="https://wa.me/254793019606?text=Hello%20Sokiva%2C%20I%20need%20help" 
       class="whatsapp-float" 
       target="_blank" 
       aria-label="Chat on WhatsApp">
        <i class="fab fa-whatsapp"></i>
    </a>
</body>
</html>