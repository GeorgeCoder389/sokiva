<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'sokiva');

// Site configuration
define('SITE_NAME', 'SOKIVA');
define('SITE_TAGLINE', 'Find your laptop. Good laptops. Access them through Sokiva.');
define('SITE_URL', 'http://localhost/sokiva/'); // CHANGE THIS TO YOUR LIVE URL
define('CURRENCY', 'KES');
define('PHONE_NUMBER', '0793019606');
define('EMAIL', 'sokivagadg@gmail.com');

// Social Media Links
define('INSTAGRAM_URL', 'https://www.instagram.com/sokivagadgets/');
define('TIKTOK_URL', 'https://www.tiktok.com/@sokivagadgets');
define('WHATSAPP_CHANNEL', 'https://whatsapp.com/channel/0029VbCfNcUHgZWk5yLEC03x');
define('WHATSAPP_NUMBER', '254793019606');

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Database connection
try {
    $conn = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>