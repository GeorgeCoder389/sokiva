<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = (int)$_POST['product_id'];
    unset($_SESSION['cart'][$product_id]);
}

header('Location: cart.php');
exit;
?>