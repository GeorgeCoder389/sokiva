<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

// Database connection
$host = 'localhost';
$dbname = 'sokiva';
$username = 'root';
$password = '';

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Check if cart is empty
if (empty($_SESSION['cart'])) {
    header('Location: cart.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $first_name = trim($_POST['first_name'] ?? '');
    $last_name = trim($_POST['last_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $payment_method = trim($_POST['payment_method'] ?? '');
    
    // Validate
    if (empty($first_name) || empty($last_name) || empty($email) || empty($phone) || empty($address) || empty($payment_method)) {
        $_SESSION['checkout_error'] = 'Please fill in all fields.';
        header('Location: checkout.php');
        exit;
    }
    
    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['checkout_error'] = 'Please enter a valid email address.';
        header('Location: checkout.php');
        exit;
    }
    
    // Calculate total
    $total = 0;
    $order_items = array();
    
    $ids = array_keys($_SESSION['cart']);
    if (empty($ids)) {
        header('Location: cart.php');
        exit;
    }
    
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $conn->prepare("SELECT * FROM products WHERE id IN ($placeholders)");
    $stmt->execute($ids);
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($products as $product) {
        $qty = $_SESSION['cart'][$product['id']];
        $subtotal = $product['price'] * $qty;
        $total += $subtotal;
        $order_items[] = array(
            'product' => $product,
            'qty' => $qty,
            'subtotal' => $subtotal
        );
    }
    
    try {
        // First, drop the old orders table if it exists with wrong structure
        $conn->exec("DROP TABLE IF EXISTS order_items");
        $conn->exec("DROP TABLE IF EXISTS orders");
        
        // Create orders table with correct column names (using backticks for reserved words)
        $conn->exec("CREATE TABLE orders (
            id INT AUTO_INCREMENT PRIMARY KEY,
            first_name VARCHAR(100) NOT NULL,
            last_name VARCHAR(100) NOT NULL,
            email VARCHAR(255) NOT NULL,
            phone VARCHAR(50) NOT NULL,
            address TEXT NOT NULL,
            payment_method VARCHAR(50) NOT NULL,
            total DECIMAL(10,2) NOT NULL DEFAULT 0,
            order_status VARCHAR(50) DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )");
        
        // Create order_items table
        $conn->exec("CREATE TABLE order_items (
            id INT AUTO_INCREMENT PRIMARY KEY,
            order_id INT NOT NULL,
            product_id INT NOT NULL,
            product_name VARCHAR(255) NOT NULL,
            price DECIMAL(10,2) NOT NULL,
            quantity INT NOT NULL,
            subtotal DECIMAL(10,2) NOT NULL,
            FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
        )");
        
        // Save order - using the correct column names
        $stmt = $conn->prepare("INSERT INTO orders (first_name, last_name, email, phone, address, payment_method, total, order_status) 
                                VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')");
        $stmt->execute([$first_name, $last_name, $email, $phone, $address, $payment_method, $total]);
        $order_id = $conn->lastInsertId();
        
        // Save order items
        foreach ($order_items as $item) {
            $stmt = $conn->prepare("INSERT INTO order_items (order_id, product_id, product_name, price, quantity, subtotal) 
                                    VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                $order_id,
                $item['product']['id'],
                $item['product']['name'],
                $item['product']['price'],
                $item['qty'],
                $item['subtotal']
            ]);
        }
        
        // Clear cart
        $_SESSION['cart'] = array();
        
        // Redirect to success page
        header('Location: order_success.php?order_id=' . $order_id);
        exit;
        
    } catch(PDOException $e) {
        $_SESSION['checkout_error'] = 'Error placing order: ' . $e->getMessage();
        header('Location: checkout.php');
        exit;
    }
} else {
    header('Location: checkout.php');
    exit;
}
?>