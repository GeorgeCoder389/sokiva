<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

// Database connection
$host = 'localhost';
$dbname = 'sokiva';
$username = 'root';
$password = '';

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Initialize cart if not exists
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}

$cart_items = array();
$total = 0;

if (!empty($_SESSION['cart'])) {
    $ids = array_keys($_SESSION['cart']);
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $conn->prepare("SELECT * FROM products WHERE id IN ($placeholders)");
    $stmt->execute($ids);
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($products as $product) {
        $qty = $_SESSION['cart'][$product['id']];
        $subtotal = $product['price'] * $qty;
        $cart_items[] = array(
            'product' => $product,
            'qty' => $qty,
            'subtotal' => $subtotal
        );
        $total += $subtotal;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart - SOKIVA</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* ===== RESET ===== */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Baloo 2', sans-serif;
            background: #ffffff;
            color: #1a1a1a;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 1.5rem;
        }
        
        /* ===== HEADER ===== */
        .header {
            background: #ffffff;
            padding: 0.8rem 2rem;
            border-bottom: 1px solid #e5e7eb;
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        
        .header-container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        .logo {
            font-family: 'Baloo 2', sans-serif;
            font-weight: 800;
            font-size: 1.6rem;
            letter-spacing: 3px;
            color: #1a1a1a;
            text-transform: uppercase;
            text-decoration: none;
        }
        
        .logo span {
            color: #6b7280;
        }
        
        .tagline {
            color: #6b7280;
            font-size: 0.85rem;
            font-weight: 400;
            display: none;
        }
        
        @media (min-width: 768px) {
            .tagline {
                display: inline;
            }
        }
        
        .nav-menu {
            display: flex;
            align-items: center;
            gap: 2rem;
            list-style: none;
        }
        
        .nav-menu a {
            color: #333333;
            text-decoration: none;
            font-weight: 500;
            font-size: 1rem;
            transition: all 0.3s ease;
            position: relative;
        }
        
        .nav-menu a::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 0;
            height: 2px;
            background: #1a1a1a;
            transition: all 0.3s ease;
        }
        
        .nav-menu a:hover {
            color: #1a1a1a;
        }
        
        .nav-menu a:hover::after {
            width: 100%;
        }
        
        .nav-menu a.active {
            color: #1a1a1a;
            font-weight: 600;
        }
        
        .nav-menu a.active::after {
            width: 100%;
        }
        
        .cart-icon {
            position: relative;
            font-size: 1.2rem;
            color: #333333;
        }
        
        .cart-icon:hover {
            color: #1a1a1a;
        }
        
        .cart-badge {
            position: absolute;
            top: -8px;
            right: -10px;
            background: #1a1a1a;
            color: white;
            font-size: 0.65rem;
            font-weight: 700;
            width: 18px;
            height: 18px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .hamburger {
            display: none;
            flex-direction: column;
            gap: 5px;
            cursor: pointer;
            background: none;
            border: none;
            padding: 0.3rem;
        }
        
        .hamburger span {
            width: 25px;
            height: 3px;
            background: #1a1a1a;
            border-radius: 3px;
            transition: all 0.3s ease;
        }
        
        @media (max-width: 768px) {
            .hamburger {
                display: flex;
            }
            
            .nav-menu {
                display: none;
                flex-direction: column;
                width: 100%;
                padding: 1rem 0;
                border-top: 1px solid #e5e7eb;
                gap: 0.8rem;
            }
            
            .nav-menu.open {
                display: flex;
            }
            
            .nav-menu a {
                font-size: 1.1rem;
                padding: 0.5rem 0;
            }
        }
        
        /* ===== HERO ===== */
        .hero {
            background: #f8f8f8;
            padding: 2.5rem 2rem;
            text-align: center;
            border-bottom: 1px solid #e5e7eb;
            margin-bottom: 2rem;
        }
        
        .hero h1 {
            font-size: 2.2rem;
            font-weight: 800;
            letter-spacing: 1px;
            margin-bottom: 0.5rem;
            color: #1a1a1a;
        }
        
        .hero p {
            font-size: 1.1rem;
            font-weight: 400;
            color: #6b7280;
            max-width: 600px;
            margin: 0 auto;
        }
        
        @media (max-width: 768px) {
            .hero h1 {
                font-size: 1.8rem;
            }
        }
        
        /* ===== BUTTONS ===== */
        .btn {
            display: inline-block;
            padding: 0.7rem 1.8rem;
            border-radius: 8px;
            text-decoration: none;
            font-family: 'Baloo 2', sans-serif;
            font-weight: 600;
            font-size: 0.95rem;
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
            text-align: center;
        }
        
        .btn-primary {
            background: #1a1a1a;
            color: #ffffff;
        }
        
        .btn-primary:hover {
            background: #333333;
            transform: translateY(-2px);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
        }
        
        .btn-secondary {
            background: #ffffff;
            color: #1a1a1a;
            border: 1px solid #e5e7eb;
        }
        
        .btn-secondary:hover {
            background: #f8f8f8;
        }
        
        .btn-danger {
            background: #dc2626;
            color: #ffffff;
        }
        
        .btn-danger:hover {
            background: #b91c1c;
        }
        
        .btn-sm {
            padding: 0.3rem 0.8rem;
            font-size: 0.85rem;
        }
        
        /* ===== CART ===== */
        .cart-empty {
            text-align: center;
            padding: 3rem;
            background: #ffffff;
            border-radius: 12px;
            border: 1px solid #e5e7eb;
            max-width: 600px;
            margin: 0 auto;
        }
        
        .cart-empty i {
            font-size: 4rem;
            color: #9ca3af;
            margin-bottom: 1rem;
        }
        
        .cart-empty h3 {
            font-weight: 600;
            color: #1a1a1a;
        }
        
        .cart-empty p {
            color: #6b7280;
        }
        
        .cart-item {
            background: #ffffff;
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 1rem;
            border: 1px solid #e5e7eb;
            display: flex;
            align-items: center;
            gap: 1.5rem;
            transition: all 0.3s ease;
        }
        
        .cart-item:hover {
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
        }
        
        .cart-item-image {
            width: 80px;
            height: 80px;
            background: #f8f8f8;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2.5rem;
            color: #6b7280;
            flex-shrink: 0;
            border: 1px solid #e5e7eb;
            overflow: hidden;
        }
        
        .cart-item-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .cart-item-info {
            flex: 1;
        }
        
        .cart-item-info h4 {
            font-weight: 600;
            font-size: 1.1rem;
            color: #1a1a1a;
        }
        
        .cart-item-info .specs {
            color: #6b7280;
            font-size: 0.85rem;
        }
        
        .cart-item-info .price {
            font-weight: 700;
            font-size: 1.1rem;
            color: #1a1a1a;
        }
        
        .cart-item-actions {
            display: flex;
            align-items: center;
            gap: 0.8rem;
            flex-wrap: wrap;
        }
        
        .cart-item-actions .qty-control {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .cart-item-actions .qty-control button {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            border: 1px solid #e5e7eb;
            background: #ffffff;
            cursor: pointer;
            font-size: 1rem;
            transition: all 0.3s ease;
            font-family: 'Baloo 2', sans-serif;
        }
        
        .cart-item-actions .qty-control button:hover {
            background: #f8f8f8;
        }
        
        .cart-item-actions .qty-control span {
            font-weight: 600;
            font-size: 1.1rem;
            min-width: 30px;
            text-align: center;
        }
        
        .cart-item-actions .item-total {
            font-weight: 700;
            font-size: 1.1rem;
            color: #1a1a1a;
            min-width: 100px;
            text-align: right;
        }
        
        /* ===== CART SUMMARY ===== */
        .cart-summary {
            background: #f8f8f8;
            border-radius: 12px;
            padding: 2rem;
            margin-top: 2rem;
            border: 1px solid #e5e7eb;
        }
        
        .cart-summary .total-row {
            display: flex;
            justify-content: space-between;
            font-size: 1.3rem;
            font-weight: 700;
            padding: 1rem 0;
            border-top: 2px solid #e5e7eb;
        }
        
        .cart-summary .total-row .amount {
            font-size: 1.8rem;
            color: #1a1a1a;
        }
        
        .cart-summary .actions {
            display: flex;
            gap: 1rem;
            margin-top: 1.5rem;
            flex-wrap: wrap;
        }
        
        .cart-summary .actions .btn {
            flex: 1;
            min-width: 150px;
        }
        
        /* ===== FOOTER ===== */
        .footer {
            background: #f8f8f8;
            padding: 2.5rem 2rem 1.5rem;
            margin-top: 2rem;
            border-top: 1px solid #e5e7eb;
        }
        
        .footer-container {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 2rem;
        }
        
        .footer h4 {
            font-weight: 700;
            font-size: 1rem;
            margin-bottom: 0.8rem;
            color: #1a1a1a;
        }
        
        .footer ul {
            list-style: none;
        }
        
        .footer ul li {
            margin-bottom: 0.4rem;
        }
        
        .footer ul a {
            color: #6b7280;
            text-decoration: none;
            transition: all 0.3s ease;
            font-size: 0.9rem;
        }
        
        .footer ul a:hover {
            color: #1a1a1a;
        }
        
        .footer-bottom {
            text-align: center;
            padding-top: 1.5rem;
            margin-top: 1.5rem;
            border-top: 1px solid #e5e7eb;
            color: #9ca3af;
            font-size: 0.85rem;
        }
        
        .footer-logo {
            font-weight: 800;
            font-size: 1.3rem;
            letter-spacing: 3px;
            text-transform: uppercase;
            color: #1a1a1a;
        }
        
        .footer-logo span {
            color: #6b7280;
        }
        
        /* ===== WHATSAPP FLOAT ===== */
        .whatsapp-float {
            position: fixed;
            bottom: 30px;
            right: 30px;
            background: #25D366;
            color: white;
            width: 55px;
            height: 55px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            box-shadow: 0 4px 20px rgba(37, 211, 102, 0.3);
            transition: all 0.3s ease;
            z-index: 999;
            text-decoration: none;
        }
        
        .whatsapp-float:hover {
            transform: scale(1.1);
            box-shadow: 0 8px 30px rgba(37, 211, 102, 0.4);
        }
        
        /* ===== RESPONSIVE ===== */
        @media (max-width: 768px) {
            .cart-item {
                flex-direction: column;
                text-align: center;
            }
            .cart-item-actions {
                justify-content: center;
            }
            .cart-item-actions .item-total {
                text-align: center;
            }
            .cart-summary .actions {
                flex-direction: column;
            }
            .cart-summary .actions .btn {
                width: 100%;
            }
        }
        
        @media (max-width: 576px) {
            .footer-container {
                grid-template-columns: 1fr;
                text-align: center;
            }
            .btn {
                padding: 0.5rem 1.2rem;
                font-size: 0.85rem;
            }
        }
    </style>
</head>
<body>
    <!-- ===== HEADER ===== -->
    <header class="header">
        <div class="header-container">
            <a href="/sokiva/" class="logo">SOKIVA <span>.</span></a>
            <span class="tagline">Access your desire.</span>
            
            <button class="hamburger" id="hamburger" aria-label="Toggle menu">
                <span></span>
                <span></span>
                <span></span>
            </button>
            
            <nav>
                <ul class="nav-menu" id="navMenu">
                    <li><a href="/sokiva/">Home</a></li>
                    <li><a href="/sokiva/shop.php">All Laptops</a></li>
                    <li><a href="/sokiva/contact.php">Contact</a></li>
                    <li>
                        <a href="/sokiva/cart.php" class="cart-icon active">
                            <i class="fas fa-shopping-cart"></i>
                            <?php
                            $cart_count = isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0;
                            if ($cart_count > 0) {
                                echo '<span class="cart-badge">' . $cart_count . '</span>';
                            }
                            ?>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </header>
    
    <script>
        document.getElementById('hamburger').addEventListener('click', function() {
            document.getElementById('navMenu').classList.toggle('open');
        });
    </script>

    <!-- ===== HERO ===== -->
    <section class="hero">
        <div class="container">
            <h1>Your <span style="color: #1a1a1a;">Shopping Cart</span></h1>
            <p>Review your items and proceed to checkout</p>
        </div>
    </section>

    <!-- ===== MAIN CONTENT ===== -->
    <main class="container" style="padding: 0 1.5rem 3rem;">
        
        <?php if (empty($cart_items)): ?>
        <!-- Empty Cart -->
        <div class="cart-empty">
            <i class="fas fa-shopping-cart"></i>
            <h3>Your cart is empty</h3>
            <p>Browse our laptops and add your favorites!</p>
            <a href="/sokiva/shop.php" class="btn btn-primary" style="margin-top: 1rem;">
                <i class="fas fa-arrow-left"></i> Start Shopping
            </a>
        </div>
        <?php else: ?>
        
        <!-- Cart Items -->
        <?php foreach ($cart_items as $item): ?>
        <div class="cart-item" id="item-<?php echo $item['product']['id']; ?>">
            <div class="cart-item-image">
                <?php if (!empty($item['product']['image']) && file_exists('uploads/products/' . $item['product']['image'])): ?>
                    <img src="uploads/products/<?php echo $item['product']['image']; ?>" alt="<?php echo htmlspecialchars($item['product']['name']); ?>">
                <?php else: ?>
                    <i class="fas fa-laptop"></i>
                <?php endif; ?>
            </div>
            <div class="cart-item-info">
                <h4><?php echo htmlspecialchars($item['product']['name']); ?></h4>
                <p class="specs"><?php echo htmlspecialchars($item['product']['specs']); ?></p>
                <span class="price">KES <?php echo number_format($item['product']['price']); ?></span>
            </div>
            <div class="cart-item-actions">
                <div class="qty-control">
                    <button onclick="updateCart(<?php echo $item['product']['id']; ?>, -1)">-</button>
                    <span><?php echo $item['qty']; ?></span>
                    <button onclick="updateCart(<?php echo $item['product']['id']; ?>, 1)">+</button>
                </div>
                <div class="item-total">
                    KES <?php echo number_format($item['subtotal']); ?>
                </div>
                <button onclick="removeFromCart(<?php echo $item['product']['id']; ?>)" class="btn btn-danger btn-sm">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
        <?php endforeach; ?>
        
        <!-- Cart Summary -->
        <div class="cart-summary">
            <div class="total-row">
                <span>Total:</span>
                <span class="amount">KES <?php echo number_format($total); ?></span>
            </div>
            <div class="actions">
                <a href="/sokiva/checkout.php" class="btn btn-primary">
                    <i class="fas fa-credit-card"></i> Proceed to Checkout
                </a>
                <a href="/sokiva/shop.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Continue Shopping
                </a>
            </div>
        </div>
        
        <?php endif; ?>
    </main>

    <!-- ===== FOOTER ===== -->
    <footer class="footer">
        <div class="footer-container">
            <div>
                <div class="footer-logo">SOKIVA <span>.</span></div>
                <p style="margin-top: 0.3rem; color: #6b7280; font-size: 0.9rem;">Access your desire.</p>
            </div>
            <div>
                <h4>Quick Links</h4>
                <ul>
                    <li><a href="/sokiva/">Home</a></li>
                    <li><a href="/sokiva/shop.php">All Laptops</a></li>
                    <li><a href="/sokiva/contact.php">Contact</a></li>
                    <li><a href="/sokiva/about.php">About Us</a></li>
                </ul>
            </div>
            <div>
                <h4>Support</h4>
                <ul>
                    <li><a href="/sokiva/contact.php">Help Center</a></li>
                    <li><a href="/sokiva/privacy.php">Privacy Policy</a></li>
                    <li><a href="/sokiva/terms.php">Terms & Conditions</a></li>
                </ul>
            </div>
            <div>
                <h4>Connect With Us</h4>
                <ul>
                    <li><a href="https://wa.me/254793019606" target="_blank"><i class="fab fa-whatsapp"></i> WhatsApp</a></li>
                    <li><a href="https://www.instagram.com/sokivagadgets/" target="_blank"><i class="fab fa-instagram"></i> Instagram</a></li>
                    <li><a href="https://www.tiktok.com/@sokivagadgets" target="_blank"><i class="fab fa-tiktok"></i> TikTok</a></li>
                    <li><a href="https://whatsapp.com/channel/0029VbCfNcUHgZWk5yLEC03x" target="_blank"><i class="fab fa-whatsapp"></i> WhatsApp Channel</a></li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            &copy; <?php echo date('Y'); ?> SOKIVA. All rights reserved.
        </div>
    </footer>

    <!-- WhatsApp Float -->
    <a href="https://wa.me/254793019606?text=Hello%20Sokiva%2C%20I%20need%20help" 
       class="whatsapp-float" 
       target="_blank" 
       aria-label="Chat on WhatsApp">
        <i class="fab fa-whatsapp"></i>
    </a>

    <script>
        function updateCart(productId, change) {
            var xhr = new XMLHttpRequest();
            xhr.open('POST', '/sokiva/update_cart.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onload = function() {
                if (this.status === 200) {
                    location.reload();
                } else {
                    alert('Error updating cart. Please try again.');
                }
            };
            xhr.send('product_id=' + productId + '&change=' + change);
        }

        function removeFromCart(productId) {
            if (confirm('Remove this item from your cart?')) {
                var xhr = new XMLHttpRequest();
                xhr.open('POST', '/sokiva/remove_from_cart.php', true);
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                xhr.onload = function() {
                    if (this.status === 200) {
                        location.reload();
                    } else {
                        alert('Error removing item. Please try again.');
                    }
                };
                xhr.send('product_id=' + productId);
            }
        }
    </script>
</body>
</html>