<?php
$page_title = 'Terms & Conditions';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terms & Conditions - SOKIVA</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Baloo 2', sans-serif;
            background: #ffffff;
            color: #1a1a1a;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 1.5rem;
        }
        
        .header {
            background: #ffffff;
            padding: 0.8rem 2rem;
            border-bottom: 1px solid #e5e7eb;
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        
        .header-container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        .logo {
            font-family: 'Baloo 2', sans-serif;
            font-weight: 800;
            font-size: 1.6rem;
            letter-spacing: 3px;
            color: #1a1a1a;
            text-transform: uppercase;
            text-decoration: none;
        }
        
        .logo span {
            color: #6b7280;
        }
        
        .tagline {
            color: #6b7280;
            font-size: 0.85rem;
            font-weight: 400;
            display: none;
        }
        
        @media (min-width: 768px) {
            .tagline {
                display: inline;
            }
        }
        
        .nav-menu {
            display: flex;
            align-items: center;
            gap: 2rem;
            list-style: none;
        }
        
        .nav-menu a {
            color: #333333;
            text-decoration: none;
            font-weight: 500;
            font-size: 1rem;
            transition: all 0.3s ease;
            position: relative;
        }
        
        .nav-menu a::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 0;
            height: 2px;
            background: #1a1a1a;
            transition: all 0.3s ease;
        }
        
        .nav-menu a:hover {
            color: #1a1a1a;
        }
        
        .nav-menu a:hover::after {
            width: 100%;
        }
        
        .nav-menu a.active {
            color: #1a1a1a;
            font-weight: 600;
        }
        
        .nav-menu a.active::after {
            width: 100%;
        }
        
        .hamburger {
            display: none;
            flex-direction: column;
            gap: 5px;
            cursor: pointer;
            background: none;
            border: none;
            padding: 0.3rem;
        }
        
        .hamburger span {
            width: 25px;
            height: 3px;
            background: #1a1a1a;
            border-radius: 3px;
            transition: all 0.3s ease;
        }
        
        @media (max-width: 768px) {
            .hamburger {
                display: flex;
            }
            .nav-menu {
                display: none;
                flex-direction: column;
                width: 100%;
                padding: 1rem 0;
                border-top: 1px solid #e5e7eb;
                gap: 0.8rem;
            }
            .nav-menu.open {
                display: flex;
            }
            .nav-menu a {
                font-size: 1.1rem;
                padding: 0.5rem 0;
            }
        }
        
        .hero {
            background: #f8f8f8;
            padding: 3rem 2rem;
            text-align: center;
            border-bottom: 1px solid #e5e7eb;
            margin-bottom: 2rem;
        }
        
        .hero h1 {
            font-size: 2.5rem;
            font-weight: 800;
            letter-spacing: 1px;
            margin-bottom: 0.5rem;
            color: #1a1a1a;
        }
        
        .hero p {
            font-size: 1.1rem;
            font-weight: 400;
            color: #6b7280;
            max-width: 600px;
            margin: 0 auto;
        }
        
        @media (max-width: 768px) {
            .hero h1 {
                font-size: 1.8rem;
            }
        }
        
        .content-wrapper {
            padding: 1rem 0 3rem;
        }
        
        .content-box {
            background: #ffffff;
            border-radius: 12px;
            padding: 2.5rem;
            border: 1px solid #e5e7eb;
            max-width: 800px;
            margin: 0 auto;
        }
        
        .content-box h2 {
            font-weight: 700;
            font-size: 1.3rem;
            color: #1a1a1a;
            margin-top: 1.5rem;
            margin-bottom: 0.8rem;
        }
        
        .content-box h2:first-child {
            margin-top: 0;
        }
        
        .content-box p {
            color: #6b7280;
            line-height: 1.8;
            margin-bottom: 1rem;
        }
        
        .content-box ul {
            color: #6b7280;
            line-height: 2;
            padding-left: 1.5rem;
            margin-bottom: 1.5rem;
        }
        
        .content-box ul li {
            margin-bottom: 0.3rem;
        }
        
        .content-box ul li a {
            color: #1a1a1a;
            text-decoration: none;
        }
        
        .content-box ul li a:hover {
            text-decoration: underline;
        }
        
        .content-box ul ul {
            padding-left: 2rem;
            margin-bottom: 0.5rem;
        }
        
        .content-box .highlight-box {
            background: #f8f8f8;
            padding: 1.5rem;
            border-radius: 8px;
            border-left: 4px solid #1a1a1a;
            margin: 1rem 0;
        }
        
        .content-box .highlight-box p {
            margin-bottom: 0;
        }
        
        .footer {
            background: #f8f8f8;
            padding: 2.5rem 2rem 1.5rem;
            margin-top: 2rem;
            border-top: 1px solid #e5e7eb;
        }
        
        .footer-container {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 2rem;
        }
        
        .footer h4 {
            font-weight: 700;
            font-size: 1rem;
            margin-bottom: 0.8rem;
            color: #1a1a1a;
        }
        
        .footer ul {
            list-style: none;
        }
        
        .footer ul li {
            margin-bottom: 0.4rem;
        }
        
        .footer ul a {
            color: #6b7280;
            text-decoration: none;
            transition: all 0.3s ease;
            font-size: 0.9rem;
        }
        
        .footer ul a:hover {
            color: #1a1a1a;
        }
        
        .footer-bottom {
            text-align: center;
            padding-top: 1.5rem;
            margin-top: 1.5rem;
            border-top: 1px solid #e5e7eb;
            color: #9ca3af;
            font-size: 0.85rem;
        }
        
        .footer-logo {
            font-weight: 800;
            font-size: 1.3rem;
            letter-spacing: 3px;
            text-transform: uppercase;
            color: #1a1a1a;
        }
        
        .footer-logo span {
            color: #6b7280;
        }
        
        .whatsapp-float {
            position: fixed;
            bottom: 30px;
            right: 30px;
            background: #25D366;
            color: white;
            width: 55px;
            height: 55px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            box-shadow: 0 4px 20px rgba(37, 211, 102, 0.3);
            transition: all 0.3s ease;
            z-index: 999;
            text-decoration: none;
        }
        
        .whatsapp-float:hover {
            transform: scale(1.1);
            box-shadow: 0 8px 30px rgba(37, 211, 102, 0.4);
        }
        
        @media (max-width: 576px) {
            .footer-container {
                grid-template-columns: 1fr;
                text-align: center;
            }
            .content-box {
                padding: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="header-container">
            <a href="/sokiva/" class="logo">SOKIVA <span>.</span></a>
            <span class="tagline">Access your desire.</span>
            <button class="hamburger" id="hamburger" aria-label="Toggle menu">
                <span></span>
                <span></span>
                <span></span>
            </button>
            <nav>
                <ul class="nav-menu" id="navMenu">
                    <li><a href="/sokiva/">Home</a></li>
                    <li><a href="/sokiva/shop.php">All Laptops</a></li>
                    <li><a href="/sokiva/contact.php">Contact</a></li>
                </ul>
            </nav>
        </div>
    </header>
    
    <script>
        document.getElementById('hamburger').addEventListener('click', function() {
            document.getElementById('navMenu').classList.toggle('open');
        });
    </script>

    <section class="hero">
        <div class="container">
            <h1>Terms & Conditions</h1>
            <p>Please read these terms carefully before using our services.</p>
        </div>
    </section>

    <main class="container">
        <div class="content-wrapper">
            <div class="content-box">
                <h2>1. Agreement to Terms</h2>
                <p>By using SOKIVA's services, you agree to be bound by these Terms & Conditions. If you do not agree with any part of these terms, please do not use our services. These terms apply to all visitors, users, and others who access or use the service.</p>
                
                <div class="highlight-box">
                    <p><strong>📌 Important:</strong> Your use of SOKIVA constitutes your acceptance of these terms. If you have any questions, please contact us before using our services.</p>
                </div>
                
                <h2>2. Ordering Process</h2>
                <p>When placing an order with SOKIVA, please follow these guidelines:</p>
                <ul>
                    <li><strong>Be Direct:</strong> Please be clear and specific about what you want when placing an order. Provide accurate product names, specifications, and quantities.</li>
                    <li><strong>Order Confirmation:</strong> All orders are subject to confirmation and availability. We will confirm your order via phone call or WhatsApp within 24 hours.</li>
                    <li><strong>Accuracy:</strong> Ensure all information provided is accurate and complete. This includes delivery address, contact details, and product specifications.</li>
                    <li><strong>Agreement:</strong> By placing an order, you agree to purchase the products as described. Any changes or cancellations must be communicated immediately.</li>
                </ul>
                
                <h2>3. Security & Safety</h2>
                <p>Your safety and security are important to us. Please follow these guidelines:</p>
                <ul>
                    <li><strong>Beware of Scammers:</strong> SOKIVA only operates through our official website and WhatsApp number. We will never ask for your password, PIN, or financial details over the phone or via WhatsApp.</li>
                    <li><strong>Secure Transactions:</strong> All transactions are processed through secure channels. We recommend using official payment methods only.</li>
                    <li><strong>Authentication:</strong> Always verify you are on the official SOKIVA website before making any payment. Check the URL for "sokiva.co.ke".</li>
                    <li><strong>Report Suspicious Activity:</strong> Immediately report any suspicious activity to us. Do not engage with anyone claiming to represent SOKIVA outside our official channels.</li>
                </ul>
                
                <h2>4. Payments</h2>
                <p>We offer the following payment methods:</p>
                <ul>
                    <li><strong>Payment Methods:</strong> We accept M-Pesa, Bank Transfer, and Cash on Delivery.</li>
                    <li><strong>Confirmation:</strong> Payment confirmation must be received before order processing (except for Cash on Delivery).</li>
                    <li><strong>Refund Policy:</strong> Refunds are processed within 7-14 business days after approval.</li>
                    <li><strong>Payment Security:</strong> We use secure payment gateways to protect your financial information.</li>
                </ul>
                
                <h2>5. Delivery</h2>
                <p>Our delivery terms are as follows:</p>
                <ul>
                    <li><strong>Delivery Time:</strong> We aim to deliver within 1-3 business days after order confirmation.</li>
                    <li><strong>Delivery Charges:</strong> Delivery fees are calculated based on your location and order value.</li>
                    <li><strong>Inspection:</strong> Please inspect your product upon delivery and report any issues immediately. Do not accept damaged packages.</li>
                    <li><strong>Delivery Area:</strong> We currently deliver within Nairobi and surrounding areas. Contact us for specific locations.</li>
                </ul>
                
                <h2>6. Refund Policy</h2>
                <p>At SOKIVA, your satisfaction is our priority. If you encounter any issues with your purchase:</p>
                <ul>
                    <li><strong>Refund Guarantee:</strong> You are eligible for a full refund if:
                        <ul>
                            <li>The product is defective or damaged</li>
                            <li>The wrong product was delivered</li>
                            <li>The product does not match the description</li>
                        </ul>
                    </li>
                    <li><strong>Refund Process:</strong> Contact us within 7 days of delivery with proof of purchase and issue details.</li>
                    <li><strong>Refund Timeline:</strong> Refunds are processed within 7-14 business days after approval.</li>
                    <li><strong>Return Shipping:</strong> Return shipping costs may be covered depending on the reason for return.</li>
                </ul>
                
                <h2>7. Customer Responsibility</h2>
                <p>As a customer of SOKIVA, you agree to:</p>
                <ul>
                    <li><strong>Be Clear:</strong> Clearly communicate your requirements when ordering.</li>
                    <li><strong>Verify Details:</strong> Double-check your order details before confirmation.</li>
                    <li><strong>Honest Communication:</strong> Be honest and straightforward in all communications.</li>
                    <li><strong>Follow Guidelines:</strong> Adhere to SOKIVA's processes and guidelines.</li>
                    <li><strong>Provide Accurate Information:</strong> Ensure all information provided is correct and up-to-date.</li>
                </ul>
                
                <h2>8. Fraud Prevention</h2>
                <p>Protect yourself from fraud by following these guidelines:</p>
                <ul>
                    <li><strong>Stay Alert:</strong> Be cautious of anyone claiming to represent SOKIVA outside our official channels.</li>
                    <li><strong>Official Channels:</strong> Only use our official website (sokiva.co.ke) and verified WhatsApp number (0793019606).</li>
                    <li><strong>Report Suspicious Activity:</strong> Immediately report any suspicious activity to us via phone or WhatsApp.</li>
                    <li><strong>No Sharing:</strong> Never share your personal passwords, PINs, or financial details with anyone.</li>
                    <li><strong>Verify Before Payment:</strong> Always confirm order details with us before making any payment.</li>
                </ul>
                
                <h2>9. Limitation of Liability</h2>
                <p>SOKIVA shall not be liable for any indirect, incidental, special, consequential, or punitive damages resulting from:</p>
                <ul>
                    <li>Use or inability to use our services</li>
                    <li>Any goods or services purchased through our platform</li>
                    <li>Unauthorized access to or alteration of your data</li>
                    <li>Any other matter relating to our services</li>
                </ul>
                <p>In no event shall our total liability exceed the amount you paid for the product in question.</p>
                
                <h2>10. Changes to Terms</h2>
                <p>We reserve the right to update these Terms & Conditions at any time. We will notify you of any changes by posting the new terms on this page. The date at the top of this page indicates when it was last updated. Continued use of our services after changes constitutes acceptance of the new terms.</p>
                
                <h2>11. Governing Law</h2>
                <p>These terms shall be governed by and construed in accordance with the laws of Kenya. Any disputes arising under or in connection with these terms shall be subject to the exclusive jurisdiction of the courts of Kenya.</p>
                
                <h2>12. Contact Information</h2>
                <p>For any questions, concerns, or assistance:</p>
                <ul>
                    <li><strong>Email:</strong> sokivagadg@gmail.com</li>
                    <li><strong>Phone:</strong> 0793019606</li>
                    <li><strong>WhatsApp:</strong> 0793019606</li>
                    <li><strong>Instagram:</strong> <a href="https://www.instagram.com/sokivagadgets/" target="_blank">@sokivagadgets</a></li>
                    <li><strong>TikTok:</strong> <a href="https://www.tiktok.com/@sokivagadgets" target="_blank">@sokivagadgets</a></li>
                    <li><strong>Visit:</strong> Nairobi, Kenya</li>
                </ul>
            </div>
        </div>
    </main>

    <footer class="footer">
        <div class="footer-container">
            <div>
                <div class="footer-logo">SOKIVA <span>.</span></div>
                <p style="margin-top: 0.3rem; color: #6b7280; font-size: 0.9rem;">Access your desire.</p>
            </div>
            <div>
                <h4>Quick Links</h4>
                <ul>
                    <li><a href="/sokiva/">Home</a></li>
                    <li><a href="/sokiva/shop.php">All Laptops</a></li>
                    <li><a href="/sokiva/contact.php">Contact</a></li>
                    <li><a href="/sokiva/about.php">About Us</a></li>
                </ul>
            </div>
            <div>
                <h4>Support</h4>
                <ul>
                    <li><a href="/sokiva/contact.php">Help Center</a></li>
                    <li><a href="/sokiva/privacy.php">Privacy Policy</a></li>
                    <li><a href="/sokiva/terms.php">Terms & Conditions</a></li>
                </ul>
            </div>
            <div>
                <h4>Connect With Us</h4>
                <ul>
                    <li><a href="https://wa.me/254793019606" target="_blank"><i class="fab fa-whatsapp"></i> WhatsApp</a></li>
                    <li><a href="https://www.instagram.com/sokivagadgets/" target="_blank"><i class="fab fa-instagram"></i> Instagram</a></li>
                    <li><a href="https://www.tiktok.com/@sokivagadgets" target="_blank"><i class="fab fa-tiktok"></i> TikTok</a></li>
                    <li><a href="https://whatsapp.com/channel/0029VbCfNcUHgZWk5yLEC03x" target="_blank"><i class="fab fa-whatsapp"></i> WhatsApp Channel</a></li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            &copy; <?php echo date('Y'); ?> SOKIVA. All rights reserved.
        </div>
    </footer>

    <a href="https://wa.me/254793019606?text=Hello%20Sokiva%2C%20I%20need%20help" 
       class="whatsapp-float" 
       target="_blank" 
       aria-label="Chat on WhatsApp">
        <i class="fab fa-whatsapp"></i>
    </a>
</body>
</html>