<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require_once '../config.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit();
}

// Check if product ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header('Location: products.php');
    exit();
}

$product_id = intval($_GET['id']);

// Check if there's a confirmation
if (isset($_GET['confirm']) && $_GET['confirm'] == 'yes') {
    // Delete product
    $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
    $stmt->bind_param("i", $product_id);
    
    if ($stmt->execute()) {
        $stmt->close();
        header('Location: products.php?deleted=1');
        exit();
    } else {
        $error = 'Error deleting product: ' . $conn->error;
    }
    $stmt->close();
} else {
    // Fetch product details for confirmation
    $product = null;
    $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows == 1) {
        $product = $result->fetch_assoc();
    } else {
        header('Location: products.php');
        exit();
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SOKIVA Admin - Delete Product</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
        }
        
        .admin-header {
            background: #333;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .admin-header h1 {
            font-size: 24px;
            margin: 0;
        }
        
        .admin-nav {
            display: flex;
            gap: 15px;
            align-items: center;
        }
        
        .admin-nav a {
            color: white;
            text-decoration: none;
            padding: 8px 12px;
            border-radius: 4px;
        }
        
        .admin-nav a:hover {
            background: #555;
        }
        
        .logout-btn {
            background: #dc3545;
            color: white;
            padding: 8px 15px;
            text-decoration: none;
            border-radius: 4px;
        }
        
        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 0 20px;
        }
        
        .confirmation-box {
            background: white;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        
        .warning-icon {
            font-size: 60px;
            margin-bottom: 20px;
        }
        
        .confirmation-box h2 {
            color: #dc3545;
            margin-bottom: 20px;
        }
        
        .product-details {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
        }
        
        .product-details h3 {
            color: #333;
            margin-bottom: 10px;
        }
        
        .product-details p {
            color: #666;
            margin-bottom: 5px;
        }
        
        .button-group {
            display: flex;
            gap: 15px;
            justify-content: center;
        }
        
        .delete-btn {
            padding: 12px 24px;
            background: #dc3545;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            font-weight: bold;
            transition: background 0.3s;
        }
        
        .delete-btn:hover {
            background: #c82333;
        }
        
        .cancel-btn {
            padding: 12px 24px;
            background: #6c757d;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            font-weight: bold;
            transition: background 0.3s;
        }
        
        .cancel-btn:hover {
            background: #5a6268;
        }
        
        .error {
            background: #f8d7da;
            color: #721c24;
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="admin-header">
        <h1>SOKIVA Admin Panel</h1>
        <div class="admin-nav">
            <span>Welcome, <?php echo htmlspecialchars($_SESSION['admin_name']); ?></span>
            <a href="dashboard.php">Dashboard</a>
            <a href="products.php">Products</a>
            <a href="orders.php">Orders</a>
            <a href="logout.php" class="logout-btn">Logout</a>
        </div>
    </div>
    
    <div class="container">
        <div class="confirmation-box">
            <?php if (isset($error)): ?>
                <div class="error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <div class="warning-icon">⚠️</div>
            <h2>Delete Product</h2>
            
            <p style="color: #666; margin-bottom: 20px;">
                Are you sure you want to delete this product? This action cannot be undone.
            </p>
            
            <?php if (isset($product)): ?>
                <div class="product-details">
                    <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                    <p>Category: <?php echo htmlspecialchars($product['category'] ?? 'N/A'); ?></p>
                    <p>Price: KSh <?php echo number_format($product['price'], 2); ?></p>
                    <p>Stock: <?php echo $product['stock'] ?? 'N/A'; ?></p>
                </div>
                
                <div class="button-group">
                    <a href="delete_product.php?id=<?php echo $product_id; ?>&confirm=yes" 
                       class="delete-btn"
                       onclick="return confirm('Are you absolutely sure? This cannot be undone!');">
                        Yes, Delete
                    </a>
                    <a href="products.php" class="cancel-btn">Cancel</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>