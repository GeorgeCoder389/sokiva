<?php
session_start();

// Database connection
$host = 'localhost';
$dbname = 'sokiva';
$username = 'root';
$password = '';

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// If already logged in, redirect to dashboard
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

// Check if admin table exists, create if not
try {
    $table_check = $conn->query("SHOW TABLES LIKE 'admin'")->rowCount();
    if ($table_check == 0) {
        $conn->exec("CREATE TABLE admin (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )");
        $hashed = password_hash('admin123', PASSWORD_DEFAULT);
        $conn->exec("INSERT INTO admin (username, password) VALUES ('admin', '$hashed')");
    }
} catch(PDOException $e) {}

// Check if admin exists
try {
    $check_admin = $conn->query("SELECT COUNT(*) as count FROM admin")->fetch(PDO::FETCH_ASSOC);
    if ($check_admin['count'] == 0) {
        $hashed = password_hash('admin123', PASSWORD_DEFAULT);
        $conn->exec("INSERT INTO admin (username, password) VALUES ('admin', '$hashed')");
    }
} catch(PDOException $e) {}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        $error = 'Please enter both username and password.';
    } else {
        try {
            $stmt = $conn->prepare("SELECT * FROM admin WHERE username = ?");
            $stmt->execute([$username]);
            $admin = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($admin && password_verify($password, $admin['password'])) {
                $_SESSION['admin_logged_in'] = true;
                $_SESSION['admin_username'] = $username;
                header('Location: dashboard.php');
                exit;
            } else {
                $error = 'Invalid username or password.';
            }
        } catch(PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - SOKIVA</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Baloo 2', sans-serif;
            background: #f8f8f8;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1.5rem;
        }
        
        .login-container {
            background: #ffffff;
            border-radius: 16px;
            padding: 3rem;
            max-width: 420px;
            width: 100%;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.08);
            border: 1px solid #e5e7eb;
        }
        
        .login-header {
            text-align: center;
            margin-bottom: 2rem;
        }
        
        .login-header .logo {
            font-family: 'Baloo 2', sans-serif;
            font-weight: 800;
            font-size: 2.5rem;
            letter-spacing: 3px;
            text-transform: uppercase;
            color: #1a1a1a;
        }
        
        .login-header .logo span {
            color: #6b7280;
        }
        
        .login-header p {
            color: #6b7280;
            font-size: 1rem;
            margin-top: 0.3rem;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
            position: relative;
        }
        
        .form-group label {
            display: block;
            font-weight: 600;
            margin-bottom: 0.3rem;
            color: #1a1a1a;
        }
        
        .form-group input {
            width: 100%;
            padding: 0.8rem 1rem;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            font-family: 'Baloo 2', sans-serif;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: #ffffff;
            color: #1a1a1a;
            padding-right: 45px;
        }
        
        .form-group input:focus {
            outline: none;
            border-color: #1a1a1a;
            box-shadow: 0 0 0 3px rgba(0, 0, 0, 0.05);
        }
        
        .password-toggle {
            position: absolute;
            right: 12px;
            bottom: 10px;
            background: none;
            border: none;
            color: #6b7280;
            cursor: pointer;
            font-size: 1.1rem;
            padding: 5px;
            transition: all 0.3s ease;
        }
        
        .password-toggle:hover {
            color: #1a1a1a;
        }
        
        .btn-login {
            width: 100%;
            padding: 0.9rem;
            border-radius: 8px;
            border: none;
            background: #1a1a1a;
            color: #ffffff;
            font-family: 'Baloo 2', sans-serif;
            font-weight: 700;
            font-size: 1.1rem;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .btn-login:hover {
            background: #333333;
            transform: translateY(-2px);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
        }
        
        .error-message {
            background: #fee2e2;
            color: #991b1b;
            padding: 0.8rem 1rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            border: 1px solid #fecaca;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .success-message {
            background: #d1fae5;
            color: #065f46;
            padding: 0.8rem 1rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            border: 1px solid #a7f3d0;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .login-footer {
            text-align: center;
            margin-top: 1.5rem;
            color: #6b7280;
            font-size: 0.9rem;
        }
        
        .login-footer a {
            color: #1a1a1a;
            text-decoration: none;
            font-weight: 600;
        }
        
        .login-footer a:hover {
            text-decoration: underline;
        }
        
        @media (max-width: 480px) {
            .login-container {
                padding: 2rem;
            }
            .login-header .logo {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <div class="logo">SOKIVA <span>.</span></div>
            <p>Admin Panel Login</p>
        </div>
        
        <?php if (isset($_GET['logged_out'])): ?>
        <div class="success-message">
            <i class="fas fa-check-circle"></i>
            You have been logged out successfully.
        </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
        <div class="error-message">
            <i class="fas fa-exclamation-circle"></i>
            <?php echo $error; ?>
        </div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="form-group">
                <label for="username"><i class="fas fa-user"></i> Username</label>
                <input type="text" id="username" name="username" placeholder="Enter username" required>
            </div>
            
            <div class="form-group">
                <label for="password"><i class="fas fa-lock"></i> Password</label>
                <input type="password" id="password" name="password" placeholder="Enter password" required>
                <button type="button" class="password-toggle" onclick="togglePassword('password')">
                    <i class="fas fa-eye" id="password-icon"></i>
                </button>
            </div>
            
            <button type="submit" class="btn-login">
                <i class="fas fa-sign-in-alt"></i> Login
            </button>
        </form>
        
        <div class="login-footer">
            <p>Default: <strong>admin</strong> / <strong>admin123</strong></p>
            <p style="margin-top: 0.3rem;">
                <a href="/sokiva/"><i class="fas fa-arrow-left"></i> Back to Store</a>
            </p>
        </div>
    </div>
    
    <script>
        function togglePassword(fieldId) {
            const input = document.getElementById(fieldId);
            const icon = document.getElementById(fieldId + '-icon');
            
            if (input.type === 'password') {
                input.type = 'text';
                icon.className = 'fas fa-eye-slash';
            } else {
                input.type = 'password';
                icon.className = 'fas fa-eye';
            }
        }
    </script>
</body>
</html>