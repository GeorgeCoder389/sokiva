<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

// Database connection
$host = 'localhost';
$dbname = 'sokiva';
$username = 'root';
$password = '';

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Get product data
$stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$id]);
$product = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$product) {
    header('Location: products.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $specs = trim($_POST['specs']);
    $condition = trim($_POST['condition']);
    $price = trim($_POST['price']);
    $description = trim($_POST['description'] ?? '');
    $current_image = $_POST['current_image'] ?? '';
    
    // Handle image upload
    $image_name = $current_image;
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = '../uploads/products/';
        
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        $file_ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $image_name = time() . '_' . uniqid() . '.' . $file_ext;
        $target_file = $upload_dir . $image_name;
        
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        if (in_array($_FILES['image']['type'], $allowed_types)) {
            if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
                // Delete old image if exists
                if ($current_image && file_exists('../uploads/products/' . $current_image)) {
                    unlink('../uploads/products/' . $current_image);
                }
            } else {
                $error = 'Failed to upload image.';
            }
        } else {
            $error = 'Only JPG, PNG, GIF, and WEBP images are allowed.';
        }
    }
    
    if (empty($error)) {
        if (empty($name) || empty($specs) || empty($condition) || empty($price)) {
            $error = 'Please fill in all required fields.';
        } elseif (!is_numeric($price) || $price <= 0) {
            $error = 'Please enter a valid price.';
        } else {
            try {
                $stmt = $conn->prepare("UPDATE products SET name = ?, specs = ?, `condition` = ?, price = ?, description = ?, image = ? WHERE id = ?");
                $stmt->execute([$name, $specs, $condition, $price, $description, $image_name, $id]);
                header('Location: products.php?updated=1');
                exit;
            } catch(PDOException $e) {
                $error = 'Error updating product: ' . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product - SOKIVA</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Baloo 2', sans-serif;
            background: #f8f8f8;
            color: #1a1a1a;
        }
        
        .admin-container {
            display: flex;
            min-height: 100vh;
        }
        
        .sidebar {
            width: 250px;
            background: #ffffff;
            border-right: 1px solid #e5e7eb;
            padding: 2rem 1.5rem;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }
        
        .sidebar .logo {
            font-family: 'Baloo 2', sans-serif;
            font-weight: 800;
            font-size: 1.5rem;
            letter-spacing: 3px;
            text-transform: uppercase;
            color: #1a1a1a;
            text-decoration: none;
            display: block;
            margin-bottom: 2rem;
        }
        
        .sidebar .logo span {
            color: #6b7280;
        }
        
        .sidebar ul {
            list-style: none;
        }
        
        .sidebar ul li {
            margin-bottom: 0.3rem;
        }
        
        .sidebar ul a {
            display: flex;
            align-items: center;
            gap: 0.8rem;
            padding: 0.7rem 1rem;
            border-radius: 8px;
            color: #333333;
            text-decoration: none;
            transition: all 0.3s ease;
            font-weight: 500;
        }
        
        .sidebar ul a:hover {
            background: #f8f8f8;
        }
        
        .sidebar ul a.active {
            background: #1a1a1a;
            color: #ffffff;
        }
        
        .sidebar ul a i {
            width: 20px;
            text-align: center;
        }
        
        .sidebar .logout-btn {
            margin-top: 2rem;
            padding-top: 1rem;
            border-top: 1px solid #e5e7eb;
        }
        
        .sidebar .logout-btn a {
            color: #dc2626;
        }
        
        .sidebar .logout-btn a:hover {
            background: #fef2f2;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 2rem;
            flex: 1;
        }
        
        .main-content .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #e5e7eb;
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        .main-content .header h1 {
            font-weight: 700;
            font-size: 1.8rem;
            color: #1a1a1a;
        }
        
        .btn {
            display: inline-block;
            padding: 0.6rem 1.5rem;
            border-radius: 8px;
            text-decoration: none;
            font-family: 'Baloo 2', sans-serif;
            font-weight: 600;
            font-size: 0.95rem;
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
            text-align: center;
        }
        
        .btn-primary {
            background: #1a1a1a;
            color: #ffffff;
        }
        
        .btn-primary:hover {
            background: #333333;
            transform: translateY(-2px);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
        }
        
        .btn-secondary {
            background: #ffffff;
            color: #1a1a1a;
            border: 1px solid #e5e7eb;
        }
        
        .btn-secondary:hover {
            background: #f8f8f8;
        }
        
        .form-container {
            background: #ffffff;
            border-radius: 12px;
            padding: 2rem;
            border: 1px solid #e5e7eb;
            max-width: 800px;
        }
        
        .form-group {
            margin-bottom: 1.2rem;
        }
        
        .form-group label {
            display: block;
            font-weight: 600;
            font-size: 0.95rem;
            color: #333333;
            margin-bottom: 0.3rem;
        }
        
        .form-group label .required {
            color: #dc2626;
        }
        
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 0.7rem 1rem;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            font-family: 'Baloo 2', sans-serif;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: #ffffff;
            color: #1a1a1a;
        }
        
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #1a1a1a;
            box-shadow: 0 0 0 3px rgba(0, 0, 0, 0.05);
        }
        
        .form-group textarea {
            resize: vertical;
            min-height: 100px;
        }
        
        .form-group .image-preview {
            margin-top: 0.5rem;
            max-width: 200px;
        }
        
        .form-group .image-preview img {
            max-width: 100%;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
        }
        
        .form-actions {
            display: flex;
            gap: 1rem;
            margin-top: 1.5rem;
            flex-wrap: wrap;
        }
        
        .alert-error {
            background: #fee2e2;
            color: #991b1b;
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1rem;
            border: 1px solid #fecaca;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 200px;
                padding: 1rem;
            }
            .main-content {
                margin-left: 200px;
                padding: 1rem;
            }
        }
        
        @media (max-width: 576px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                border-right: none;
                border-bottom: 1px solid #e5e7eb;
                padding: 1rem;
            }
            .main-content {
                margin-left: 0;
                padding: 1rem;
            }
            .main-content .header {
                flex-direction: column;
                text-align: center;
            }
            .form-actions {
                flex-direction: column;
            }
            .form-actions .btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <aside class="sidebar">
            <a href="dashboard.php" class="logo">SOKIVA <span>.</span></a>
            <ul>
                <li><a href="dashboard.php"><i class="fas fa-chart-line"></i> Dashboard</a></li>
                <li><a href="products.php" class="active"><i class="fas fa-box"></i> Products</a></li>
                <li><a href="orders.php"><i class="fas fa-shopping-bag"></i> Orders</a></li>
                <li><a href="messages.php"><i class="fas fa-envelope"></i> Messages</a></li>
                <li><a href="change_password.php"><i class="fas fa-key"></i> Change Password</a></li>
                <li class="logout-btn"><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </aside>
        
        <main class="main-content">
            <div class="header">
                <h1><i class="fas fa-edit"></i> Edit Product</h1>
                <a href="products.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back to Products
                </a>
            </div>
            
            <?php if ($error): ?>
            <div class="alert-error">
                <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
            </div>
            <?php endif; ?>
            
            <div class="form-container">
                <form method="POST" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="name">Product Name <span class="required">*</span></label>
                        <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($product['name']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="specs">Specifications <span class="required">*</span></label>
                        <input type="text" id="specs" name="specs" value="<?php echo htmlspecialchars($product['specs']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="condition">Condition <span class="required">*</span></label>
                        <select id="condition" name="condition" required>
                            <option value="">Select condition...</option>
                            <option value="New" <?php echo $product['condition'] == 'New' ? 'selected' : ''; ?>>New</option>
                            <option value="Refurbished" <?php echo $product['condition'] == 'Refurbished' ? 'selected' : ''; ?>>Refurbished</option>
                            <option value="Used" <?php echo $product['condition'] == 'Used' ? 'selected' : ''; ?>>Used</option>
                            <option value="Like New" <?php echo $product['condition'] == 'Like New' ? 'selected' : ''; ?>>Like New</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="price">Price (KES) <span class="required">*</span></label>
                        <input type="number" id="price" name="price" value="<?php echo $product['price']; ?>" min="0" step="100" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="image">Product Image</label>
                        <input type="file" id="image" name="image" accept="image/*">
                        <input type="hidden" name="current_image" value="<?php echo htmlspecialchars($product['image'] ?? ''); ?>">
                        <?php if (!empty($product['image']) && file_exists('../uploads/products/' . $product['image'])): ?>
                        <div class="image-preview">
                            <img src="../uploads/products/<?php echo $product['image']; ?>" alt="Current Image">
                            <p style="font-size: 0.85rem; color: #6b7280; margin-top: 0.3rem;">Current image</p>
                        </div>
                        <?php endif; ?>
                        <p style="font-size: 0.85rem; color: #6b7280; margin-top: 0.3rem;">Upload a new image to replace the current one.</p>
                    </div>
                    
                    <div class="form-group">
                        <label for="description">Description</label>
                        <textarea id="description" name="description"><?php echo htmlspecialchars($product['description'] ?? ''); ?></textarea>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Update Product
                        </button>
                        <a href="products.php" class="btn btn-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </main>
    </div>
</body>
</html>