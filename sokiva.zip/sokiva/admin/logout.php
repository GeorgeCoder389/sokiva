<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

// If logout is confirmed
if (isset($_GET['confirm']) && $_GET['confirm'] === 'yes') {
    session_destroy();
    header('Location: login.php?logged_out=1');
    exit;
}

// If user cancels, redirect back to dashboard
if (isset($_GET['cancel'])) {
    header('Location: dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logout - SOKIVA Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Baloo 2', sans-serif;
            background: #f8f8f8;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1.5rem;
        }
        
        .logout-container {
            background: #ffffff;
            border-radius: 16px;
            padding: 3rem;
            max-width: 440px;
            width: 100%;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.08);
            border: 1px solid #e5e7eb;
            text-align: center;
        }
        
        .logout-container .icon {
            font-size: 4rem;
            color: #dc2626;
            margin-bottom: 1rem;
        }
        
        .logout-container h2 {
            font-weight: 700;
            font-size: 1.8rem;
            color: #1a1a1a;
            margin-bottom: 0.5rem;
        }
        
        .logout-container p {
            color: #6b7280;
            font-size: 1.1rem;
            margin-bottom: 2rem;
        }
        
        .logout-container .admin-info {
            background: #f8f8f8;
            padding: 0.8rem;
            border-radius: 8px;
            margin-bottom: 2rem;
            color: #333333;
            font-weight: 500;
        }
        
        .btn-group {
            display: flex;
            gap: 1rem;
            justify-content: center;
            flex-wrap: wrap;
        }
        
        .btn {
            display: inline-block;
            padding: 0.7rem 2rem;
            border-radius: 8px;
            text-decoration: none;
            font-family: 'Baloo 2', sans-serif;
            font-weight: 600;
            font-size: 1rem;
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
            text-align: center;
            min-width: 120px;
        }
        
        .btn-danger {
            background: #dc2626;
            color: #ffffff;
        }
        
        .btn-danger:hover {
            background: #b91c1c;
            transform: translateY(-2px);
            box-shadow: 0 4px 20px rgba(220, 38, 38, 0.3);
        }
        
        .btn-secondary {
            background: #ffffff;
            color: #1a1a1a;
            border: 1px solid #e5e7eb;
        }
        
        .btn-secondary:hover {
            background: #f8f8f8;
            transform: translateY(-2px);
        }
        
        .btn i {
            margin-right: 0.5rem;
        }
        
        .warning-text {
            color: #dc2626;
            font-size: 0.9rem;
            margin-top: 1.5rem;
            padding: 0.8rem;
            background: #fef2f2;
            border-radius: 8px;
            border: 1px solid #fecaca;
        }
        
        @media (max-width: 480px) {
            .logout-container {
                padding: 2rem;
            }
            .logout-container h2 {
                font-size: 1.5rem;
            }
            .btn {
                width: 100%;
            }
            .btn-group {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="logout-container">
        <div class="icon">
            <i class="fas fa-sign-out-alt"></i>
        </div>
        
        <h2>Confirm Logout</h2>
        <p>Are you sure you want to log out of the admin panel?</p>
        
        <div class="admin-info">
            <i class="fas fa-user"></i> 
            Currently logged in as: <strong><?php echo htmlspecialchars($_SESSION['admin_username'] ?? 'Admin'); ?></strong>
        </div>
        
        <div class="btn-group">
            <a href="logout.php?confirm=yes" class="btn btn-danger">
                <i class="fas fa-sign-out-alt"></i> Yes, Logout
            </a>
            <a href="logout.php?cancel=1" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Cancel
            </a>
        </div>
        
        <div class="warning-text">
            <i class="fas fa-exclamation-triangle"></i>
            You will need to login again to access the admin panel.
        </div>
    </div>
</body>
</html>