<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require_once '../config.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit();
}

// Check if order ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header('Location: orders.php');
    exit();
}

$order_id = intval($_GET['id']);

// Fetch order details
$order = null;
$stmt = $conn->prepare("SELECT * FROM orders WHERE id = ?");
$stmt->bind_param("i", $order_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 1) {
    $order = $result->fetch_assoc();
} else {
    header('Location: orders.php');
    exit();
}
$stmt->close();

// Fetch order items
$items = [];
$stmt = $conn->prepare("SELECT * FROM order_items WHERE order_id = ?");
$stmt->bind_param("i", $order_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $items[] = $row;
    }
}
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SOKIVA Admin - View Order</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
        }
        
        .admin-header {
            background: #333;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .admin-header h1 {
            font-size: 24px;
            margin: 0;
        }
        
        .admin-nav {
            display: flex;
            gap: 15px;
            align-items: center;
        }
        
        .admin-nav a {
            color: white;
            text-decoration: none;
            padding: 8px 12px;
            border-radius: 4px;
        }
        
        .admin-nav a:hover {
            background: #555;
        }
        
        .logout-btn {
            background: #dc3545;
            color: white;
            padding: 8px 15px;
            text-decoration: none;
            border-radius: 4px;
        }
        
        .container {
            max-width: 800px;
            margin: 30px auto;
            padding: 0 20px;
        }
        
        .back-btn {
            display: inline-block;
            margin-bottom: 20px;
            color: #007bff;
            text-decoration: none;
        }
        
        .back-btn:hover {
            text-decoration: underline;
        }
        
        .order-details {
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .order-header {
            background: #f8f9fa;
            padding: 20px 30px;
            border-bottom: 1px solid #dee2e6;
        }
        
        .order-header h2 {
            color: #333;
            margin-bottom: 10px;
        }
        
        .order-info {
            padding: 30px;
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .info-item {
            margin-bottom: 15px;
        }
        
        .info-item label {
            display: block;
            color: #666;
            font-size: 12px;
            margin-bottom: 5px;
        }
        
        .info-item p {
            color: #333;
            font-weight: bold;
        }
        
        .items-section {
            margin-bottom: 30px;
        }
        
        .items-section h3 {
            margin-bottom: 20px;
            color: #333;
        }
        
        .items-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .items-table th {
            background: #f8f9fa;
            padding: 12px;
            text-align: left;
            font-size: 14px;
        }
        
        .items-table td {
            padding: 12px;
            border-bottom: 1px solid #dee2e6;
            font-size: 14px;
        }
        
        .total-section {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            text-align: right;
        }
        
        .total-section h3 {
            font-size: 24px;
            color: #333;
        }
    </style>
</head>
<body>
    <div class="admin-header">
        <h1>SOKIVA Admin Panel</h1>
        <div class="admin-nav">
            <span>Welcome, <?php echo htmlspecialchars($_SESSION['admin_name']); ?></span>
            <a href="dashboard.php">Dashboard</a>
            <a href="products.php">Products</a>
            <a href="orders.php">Orders</a>
            <a href="logout.php" class="logout-btn">Logout</a>
        </div>
    </div>
    
    <div class="container">
        <a href="orders.php" class="back-btn">← Back to Orders</a>
        
        <div class="order-details">
            <div class="order-header">
                <h2>Order: <?php echo htmlspecialchars($order['order_number']); ?></h2>
                <p style="color: #666;">Placed on: <?php echo date('F j, Y \a\t g:i A', strtotime($order['created_at'])); ?></p>
            </div>
            
            <div class="order-info">
                <div class="info-grid">
                    <div class="info-item">
                        <label>Customer Name</label>
                        <p><?php echo htmlspecialchars($order['customer_name']); ?></p>
                    </div>
                    
                    <div class="info-item">
                        <label>Email</label>
                        <p><?php echo htmlspecialchars($order['email']); ?></p>
                    </div>
                    
                    <div class="info-item">
                        <label>Phone</label>
                        <p><?php echo htmlspecialchars($order['phone']); ?></p>
                    </div>
                    
                    <div class="info-item">
                        <label>City</label>
                        <p><?php echo htmlspecialchars($order['city']); ?></p>
                    </div>
                    
                    <div class="info-item">
                        <label>Delivery Address</label>
                        <p><?php echo nl2br(htmlspecialchars($order['address'])); ?></p>
                    </div>
                    
                    <div class="info-item">
                        <label>Payment Method</label>
                        <p><?php echo ucwords(str_replace('_', ' ', $order['payment_method'])); ?></p>
                    </div>
                    
                    <div class="info-item">
                        <label>Status</label>
                        <p><?php echo ucfirst($order['status']); ?></p>
                    </div>
                </div>
                
                <?php if (!empty($order['notes'])): ?>
                    <div class="info-item" style="margin-bottom: 20px;">
                        <label>Order Notes</label>
                        <p><?php echo nl2br(htmlspecialchars($order['notes'])); ?></p>
                    </div>
                <?php endif; ?>
                
                <div class="items-section">
                    <h3>Order Items</h3>
                    <table class="items-table">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($items as $item): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                                    <td>KSh <?php echo number_format($item['unit_price'], 2); ?></td>
                                    <td><?php echo $item['quantity']; ?></td>
                                    <td>KSh <?php echo number_format($item['subtotal'], 2); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="total-section">
                    <h3>Total: KSh <?php echo number_format($order['total_amount'], 2); ?></h3>
                </div>
            </div>
        </div>
    </div>
</body>
</html>