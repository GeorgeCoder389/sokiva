<?php
$host = 'localhost';
$dbname = 'sokiva';
$username = 'root';
$password = '';

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Drop existing table
$conn->exec("DROP TABLE IF EXISTS admin");

// Create admin table
$conn->exec("CREATE TABLE admin (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

// Insert admin with password 'admin123'
$hashed = password_hash('admin123', PASSWORD_DEFAULT);
$conn->exec("INSERT INTO admin (username, password) VALUES ('admin', '$hashed')");

echo "Admin created successfully!<br>";
echo "Username: <strong>admin</strong><br>";
echo "Password: <strong>admin123</strong><br>";
echo "<a href='login.php'>Go to Login</a>";
?>