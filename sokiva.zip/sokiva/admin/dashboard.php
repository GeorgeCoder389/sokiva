<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

// Database connection
$host = 'localhost';
$dbname = 'sokiva';
$username = 'root';
$password = '';

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Get statistics with error handling
$product_count = 0;
$order_count = 0;
$total_revenue = 0;
$pending_orders = 0;

try {
    $product_count = $conn->query("SELECT COUNT(*) as count FROM products")->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
} catch(PDOException $e) {
    $product_count = 0;
}

try {
    // Check if orders table exists
    $table_check = $conn->query("SHOW TABLES LIKE 'orders'")->rowCount();
    if ($table_check > 0) {
        $order_count = $conn->query("SELECT COUNT(*) as count FROM orders")->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
        
        // Check if total column exists
        $column_check = $conn->query("SHOW COLUMNS FROM orders LIKE 'total'")->rowCount();
        if ($column_check > 0) {
            $total_revenue = $conn->query("SELECT SUM(total) as total FROM orders WHERE order_status != 'cancelled'")->fetch(PDO::FETCH_ASSOC)['total'] ?? 0;
        } else {
            $total_revenue = 0;
        }
        
        // Check if order_status column exists
        $status_check = $conn->query("SHOW COLUMNS FROM orders LIKE 'order_status'")->rowCount();
        if ($status_check > 0) {
            $pending_orders = $conn->query("SELECT COUNT(*) as count FROM orders WHERE order_status = 'pending'")->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
        } else {
            $pending_orders = 0;
        }
    }
} catch(PDOException $e) {
    $order_count = 0;
    $total_revenue = 0;
    $pending_orders = 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - SOKIVA</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Baloo 2', sans-serif;
            background: #f8f8f8;
            color: #1a1a1a;
        }
        
        .admin-container {
            display: flex;
            min-height: 100vh;
        }
        
        /* ===== SIDEBAR ===== */
        .sidebar {
            width: 250px;
            background: #ffffff;
            border-right: 1px solid #e5e7eb;
            padding: 2rem 1.5rem;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }
        
        .sidebar .logo {
            font-family: 'Baloo 2', sans-serif;
            font-weight: 800;
            font-size: 1.5rem;
            letter-spacing: 3px;
            text-transform: uppercase;
            color: #1a1a1a;
            text-decoration: none;
            display: block;
            margin-bottom: 2rem;
        }
        
        .sidebar .logo span {
            color: #6b7280;
        }
        
        .sidebar ul {
            list-style: none;
        }
        
        .sidebar ul li {
            margin-bottom: 0.3rem;
        }
        
        .sidebar ul a {
            display: flex;
            align-items: center;
            gap: 0.8rem;
            padding: 0.7rem 1rem;
            border-radius: 8px;
            color: #333333;
            text-decoration: none;
            transition: all 0.3s ease;
            font-weight: 500;
        }
        
        .sidebar ul a:hover {
            background: #f8f8f8;
        }
        
        .sidebar ul a.active {
            background: #1a1a1a;
            color: #ffffff;
        }
        
        .sidebar ul a i {
            width: 20px;
            text-align: center;
        }
        
        .sidebar .logout-btn {
            margin-top: 2rem;
            padding-top: 1rem;
            border-top: 1px solid #e5e7eb;
        }
        
        .sidebar .logout-btn a {
            color: #dc2626;
        }
        
        .sidebar .logout-btn a:hover {
            background: #fef2f2;
        }
        
        /* ===== MAIN CONTENT ===== */
        .main-content {
            margin-left: 250px;
            padding: 2rem;
            flex: 1;
        }
        
        .main-content .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #e5e7eb;
        }
        
        .main-content .header h1 {
            font-weight: 700;
            font-size: 1.8rem;
            color: #1a1a1a;
        }
        
        .main-content .header .admin-info {
            color: #6b7280;
        }
        
        /* ===== STATS ===== */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background: #ffffff;
            padding: 1.5rem;
            border-radius: 12px;
            border: 1px solid #e5e7eb;
            text-align: center;
            transition: all 0.3s ease;
        }
        
        .stat-card:hover {
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
        }
        
        .stat-card .stat-icon {
            font-size: 2rem;
            color: #1a1a1a;
            margin-bottom: 0.5rem;
        }
        
        .stat-card .stat-number {
            font-size: 2.5rem;
            font-weight: 800;
            color: #1a1a1a;
        }
        
        .stat-card .stat-label {
            color: #6b7280;
            font-weight: 500;
            font-size: 0.9rem;
        }
        
        /* ===== QUICK ACTIONS ===== */
        .quick-actions {
            background: #ffffff;
            padding: 2rem;
            border-radius: 12px;
            border: 1px solid #e5e7eb;
        }
        
        .quick-actions h3 {
            font-weight: 700;
            margin-bottom: 1rem;
            color: #1a1a1a;
        }
        
        .quick-actions .actions {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
        }
        
        .btn {
            display: inline-block;
            padding: 0.7rem 1.5rem;
            border-radius: 8px;
            text-decoration: none;
            font-family: 'Baloo 2', sans-serif;
            font-weight: 600;
            font-size: 0.95rem;
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
            text-align: center;
        }
        
        .btn-primary {
            background: #1a1a1a;
            color: #ffffff;
        }
        
        .btn-primary:hover {
            background: #333333;
            transform: translateY(-2px);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
        }
        
        .btn-secondary {
            background: #ffffff;
            color: #1a1a1a;
            border: 1px solid #e5e7eb;
        }
        
        .btn-secondary:hover {
            background: #f8f8f8;
        }
        
        /* ===== WELCOME BANNER ===== */
        .welcome-banner {
            background: #ffffff;
            padding: 1.5rem 2rem;
            border-radius: 12px;
            border: 1px solid #e5e7eb;
            margin-bottom: 2rem;
        }
        
        .welcome-banner h2 {
            font-weight: 700;
            color: #1a1a1a;
        }
        
        .welcome-banner p {
            color: #6b7280;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 200px;
                padding: 1rem;
            }
            .main-content {
                margin-left: 200px;
                padding: 1rem;
            }
            .stats-grid {
                grid-template-columns: 1fr 1fr;
            }
        }
        
        @media (max-width: 576px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                border-right: none;
                border-bottom: 1px solid #e5e7eb;
                padding: 1rem;
            }
            .main-content {
                margin-left: 0;
                padding: 1rem;
            }
            .stats-grid {
                grid-template-columns: 1fr;
            }
            .main-content .header {
                flex-direction: column;
                text-align: center;
                gap: 0.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <a href="dashboard.php" class="logo">SOKIVA <span>.</span></a>
            <ul>
                <li><a href="dashboard.php" class="active"><i class="fas fa-chart-line"></i> Dashboard</a></li>
                <li><a href="products.php"><i class="fas fa-box"></i> Products</a></li>
                <li><a href="orders.php"><i class="fas fa-shopping-bag"></i> Orders</a></li>
                <li class="logout-btn"><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </aside>
        
        <!-- Main Content -->
        <main class="main-content">
            <div class="header">
                <h1><i class="fas fa-tachometer-alt"></i> Dashboard</h1>
                <span class="admin-info">Welcome, <?php echo htmlspecialchars($_SESSION['admin_username'] ?? 'Admin'); ?></span>
            </div>
            
            <!-- Welcome Banner -->
            <div class="welcome-banner">
                <h2>Welcome back!</h2>
                <p>Here's an overview of your store's performance.</p>
            </div>
            
            <!-- Stats -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-box"></i></div>
                    <div class="stat-number"><?php echo $product_count; ?></div>
                    <div class="stat-label">Total Products</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-shopping-bag"></i></div>
                    <div class="stat-number"><?php echo $order_count; ?></div>
                    <div class="stat-label">Total Orders</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-money-bill-wave"></i></div>
                    <div class="stat-number">KES <?php echo number_format($total_revenue); ?></div>
                    <div class="stat-label">Total Revenue</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-clock"></i></div>
                    <div class="stat-number"><?php echo $pending_orders; ?></div>
                    <div class="stat-label">Pending Orders</div>
                </div>
            </div>
            
            <!-- Quick Actions -->
            <div class="quick-actions">
                <h3><i class="fas fa-bolt"></i> Quick Actions</h3>
                <div class="actions">
                    <a href="add_product.php" class="btn btn-primary">
                        <i class="fas fa-plus"></i> Add New Product
                    </a>
                    <a href="orders.php" class="btn btn-secondary">
                        <i class="fas fa-eye"></i> View Orders
                    </a>
                    <a href="/sokiva/" class="btn btn-secondary" target="_blank">
                        <i class="fas fa-external-link-alt"></i> View Store
                    </a>
                </div>
            </div>
        </main>
    </div>
</body>
</html>