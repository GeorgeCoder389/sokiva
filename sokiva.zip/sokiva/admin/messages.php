<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

// Database connection
$host = 'localhost';
$dbname = 'sokiva';
$username = 'root';
$password = '';

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Check if contacts table exists, create if not
$table_check = $conn->query("SHOW TABLES LIKE 'contacts'")->rowCount();
if ($table_check == 0) {
    $conn->exec("CREATE TABLE contacts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(255) NOT NULL,
        subject VARCHAR(255) NOT NULL,
        message TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
}

// Check if is_read column exists, add if not
try {
    $column_check = $conn->query("SHOW COLUMNS FROM contacts LIKE 'is_read'")->rowCount();
    if ($column_check == 0) {
        $conn->exec("ALTER TABLE contacts ADD COLUMN is_read TINYINT(1) DEFAULT 0");
    }
} catch(PDOException $e) {
    // Column might already exist
}

// Handle delete message
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM contacts WHERE id = ?");
    $stmt->execute([$id]);
    header('Location: messages.php?deleted=1');
    exit;
}

// Handle mark as read
if (isset($_GET['read'])) {
    $id = (int)$_GET['read'];
    $stmt = $conn->prepare("UPDATE contacts SET is_read = 1 WHERE id = ?");
    $stmt->execute([$id]);
    header('Location: messages.php?read=1');
    exit;
}

// Fetch all messages - order by is_read ASC (unread first), then by created_at DESC
try {
    $messages = $conn->query("SELECT * FROM contacts ORDER BY is_read ASC, created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    // If is_read column doesn't exist yet, order by created_at only
    $messages = $conn->query("SELECT * FROM contacts ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
}

// Get unread count
$unread_count = 0;
try {
    $unread_count = $conn->query("SELECT COUNT(*) as count FROM contacts WHERE is_read = 0")->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
} catch(PDOException $e) {
    $unread_count = 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Messages - SOKIVA Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Baloo 2', sans-serif;
            background: #f8f8f8;
            color: #1a1a1a;
        }
        
        .admin-container {
            display: flex;
            min-height: 100vh;
        }
        
        .sidebar {
            width: 250px;
            background: #ffffff;
            border-right: 1px solid #e5e7eb;
            padding: 2rem 1.5rem;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }
        
        .sidebar .logo {
            font-family: 'Baloo 2', sans-serif;
            font-weight: 800;
            font-size: 1.5rem;
            letter-spacing: 3px;
            text-transform: uppercase;
            color: #1a1a1a;
            text-decoration: none;
            display: block;
            margin-bottom: 2rem;
        }
        
        .sidebar .logo span {
            color: #6b7280;
        }
        
        .sidebar ul {
            list-style: none;
        }
        
        .sidebar ul li {
            margin-bottom: 0.3rem;
        }
        
        .sidebar ul a {
            display: flex;
            align-items: center;
            gap: 0.8rem;
            padding: 0.7rem 1rem;
            border-radius: 8px;
            color: #333333;
            text-decoration: none;
            transition: all 0.3s ease;
            font-weight: 500;
            position: relative;
        }
        
        .sidebar ul a:hover {
            background: #f8f8f8;
        }
        
        .sidebar ul a.active {
            background: #1a1a1a;
            color: #ffffff;
        }
        
        .sidebar ul a i {
            width: 20px;
            text-align: center;
        }
        
        .sidebar .badge {
            background: #dc2626;
            color: white;
            font-size: 0.7rem;
            padding: 0.1rem 0.5rem;
            border-radius: 20px;
            margin-left: auto;
        }
        
        .sidebar .logout-btn {
            margin-top: 2rem;
            padding-top: 1rem;
            border-top: 1px solid #e5e7eb;
        }
        
        .sidebar .logout-btn a {
            color: #dc2626;
        }
        
        .sidebar .logout-btn a:hover {
            background: #fef2f2;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 2rem;
            flex: 1;
        }
        
        .main-content .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #e5e7eb;
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        .main-content .header h1 {
            font-weight: 700;
            font-size: 1.8rem;
            color: #1a1a1a;
        }
        
        .main-content .header .count {
            background: #1a1a1a;
            color: white;
            padding: 0.2rem 0.8rem;
            border-radius: 20px;
            font-size: 0.9rem;
        }
        
        .btn {
            display: inline-block;
            padding: 0.6rem 1.5rem;
            border-radius: 8px;
            text-decoration: none;
            font-family: 'Baloo 2', sans-serif;
            font-weight: 600;
            font-size: 0.95rem;
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
            text-align: center;
        }
        
        .btn-sm {
            padding: 0.3rem 0.8rem;
            font-size: 0.8rem;
        }
        
        .btn-secondary {
            background: #ffffff;
            color: #1a1a1a;
            border: 1px solid #e5e7eb;
        }
        
        .btn-secondary:hover {
            background: #f8f8f8;
        }
        
        .btn-danger {
            background: #dc2626;
            color: #ffffff;
        }
        
        .btn-danger:hover {
            background: #b91c1c;
        }
        
        .alert {
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1rem;
        }
        
        .alert-success {
            background: #d1fae5;
            color: #065f46;
            border: 1px solid #a7f3d0;
        }
        
        .message-card {
            background: #ffffff;
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 1rem;
            border: 1px solid #e5e7eb;
            transition: all 0.3s ease;
        }
        
        .message-card.unread {
            border-left: 4px solid #dc2626;
            background: #fef2f2;
        }
        
        .message-card:hover {
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
        }
        
        .message-card .message-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
            margin-bottom: 0.5rem;
        }
        
        .message-card .sender {
            font-weight: 700;
            font-size: 1.1rem;
            color: #1a1a1a;
        }
        
        .message-card .sender .email {
            font-weight: 400;
            color: #6b7280;
            font-size: 0.9rem;
        }
        
        .message-card .subject {
            font-weight: 600;
            color: #333333;
            margin-bottom: 0.3rem;
        }
        
        .message-card .message-text {
            color: #6b7280;
            line-height: 1.6;
            margin-bottom: 0.5rem;
        }
        
        .message-card .date {
            color: #9ca3af;
            font-size: 0.85rem;
        }
        
        .message-card .actions {
            display: flex;
            gap: 0.5rem;
            margin-top: 0.5rem;
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem;
            background: #ffffff;
            border-radius: 12px;
            border: 1px solid #e5e7eb;
        }
        
        .empty-state i {
            font-size: 3rem;
            color: #9ca3af;
            margin-bottom: 1rem;
        }
        
        .empty-state h3 {
            font-weight: 600;
            color: #1a1a1a;
        }
        
        .empty-state p {
            color: #6b7280;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 200px;
                padding: 1rem;
            }
            .main-content {
                margin-left: 200px;
                padding: 1rem;
            }
        }
        
        @media (max-width: 576px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                border-right: none;
                border-bottom: 1px solid #e5e7eb;
                padding: 1rem;
            }
            .main-content {
                margin-left: 0;
                padding: 1rem;
            }
            .message-card .message-header {
                flex-direction: column;
                align-items: flex-start;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <aside class="sidebar">
            <a href="dashboard.php" class="logo">SOKIVA <span>.</span></a>
            <ul>
                <li><a href="dashboard.php"><i class="fas fa-chart-line"></i> Dashboard</a></li>
                <li><a href="products.php"><i class="fas fa-box"></i> Products</a></li>
                <li><a href="orders.php"><i class="fas fa-shopping-bag"></i> Orders</a></li>
                <li><a href="messages.php" class="active"><i class="fas fa-envelope"></i> Messages <?php if ($unread_count > 0): ?><span class="badge"><?php echo $unread_count; ?></span><?php endif; ?></a></li>
                <li><a href="change_password.php"><i class="fas fa-key"></i> Change Password</a></li>
                <li class="logout-btn"><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </aside>
        
        <main class="main-content">
            <div class="header">
                <h1><i class="fas fa-envelope"></i> Contact Messages</h1>
                <span class="count"><?php echo $unread_count; ?> unread</span>
            </div>
            
            <?php if (isset($_GET['deleted'])): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> Message deleted successfully!
            </div>
            <?php endif; ?>
            
            <?php if (isset($_GET['read'])): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> Message marked as read!
            </div>
            <?php endif; ?>
            
            <?php if (count($messages) > 0): ?>
                <?php foreach ($messages as $msg): ?>
                <div class="message-card <?php echo (isset($msg['is_read']) && $msg['is_read'] == 0) ? 'unread' : ''; ?>">
                    <div class="message-header">
                        <div>
                            <span class="sender">
                                <?php echo htmlspecialchars($msg['name']); ?>
                                <span class="email">&lt;<?php echo htmlspecialchars($msg['email']); ?>&gt;</span>
                            </span>
                            <?php if (isset($msg['is_read']) && $msg['is_read'] == 0): ?>
                            <span style="background: #dc2626; color: white; padding: 0.1rem 0.5rem; border-radius: 20px; font-size: 0.7rem; font-weight: 600;">NEW</span>
                            <?php endif; ?>
                        </div>
                        <span class="date"><?php echo date('M d, Y H:i', strtotime($msg['created_at'])); ?></span>
                    </div>
                    <div class="subject"><?php echo htmlspecialchars($msg['subject']); ?></div>
                    <div class="message-text"><?php echo nl2br(htmlspecialchars($msg['message'])); ?></div>
                    <div class="actions">
                        <?php if (!isset($msg['is_read']) || $msg['is_read'] == 0): ?>
                        <a href="messages.php?read=<?php echo $msg['id']; ?>" class="btn btn-secondary btn-sm">
                            <i class="fas fa-check"></i> Mark as Read
                        </a>
                        <?php endif; ?>
                        <a href="messages.php?delete=<?php echo $msg['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this message?')">
                            <i class="fas fa-trash"></i> Delete
                        </a>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="empty-state">
                    <i class="fas fa-inbox"></i>
                    <h3>No messages yet</h3>
                    <p>Messages from customers will appear here.</p>
                </div>
            <?php endif; ?>
        </main>
    </div>
</body>
</html>