<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

// Database connection
$host = 'localhost';
$dbname = 'sokiva';
$username = 'root';
$password = '';

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Handle order status update
if (isset($_POST['update_status'])) {
    $order_id = (int)$_POST['order_id'];
    $order_status = $_POST['order_status'];
    
    $stmt = $conn->prepare("UPDATE orders SET order_status = ? WHERE id = ?");
    $stmt->execute([$order_status, $order_id]);
    header('Location: orders.php?updated=1');
    exit;
}

// Check if orders table exists
$table_check = $conn->query("SHOW TABLES LIKE 'orders'")->rowCount();
$orders = [];
$orders_exist = false;

if ($table_check > 0) {
    $orders_exist = true;
    try {
        $orders = $conn->query("SELECT * FROM orders ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
    } catch(PDOException $e) {
        $orders = [];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Orders - SOKIVA</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Baloo 2', sans-serif;
            background: #f8f8f8;
            color: #1a1a1a;
        }
        
        .admin-container {
            display: flex;
            min-height: 100vh;
        }
        
        .sidebar {
            width: 250px;
            background: #ffffff;
            border-right: 1px solid #e5e7eb;
            padding: 2rem 1.5rem;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }
        
        .sidebar .logo {
            font-family: 'Baloo 2', sans-serif;
            font-weight: 800;
            font-size: 1.5rem;
            letter-spacing: 3px;
            text-transform: uppercase;
            color: #1a1a1a;
            text-decoration: none;
            display: block;
            margin-bottom: 2rem;
        }
        
        .sidebar .logo span {
            color: #6b7280;
        }
        
        .sidebar ul {
            list-style: none;
        }
        
        .sidebar ul li {
            margin-bottom: 0.3rem;
        }
        
        .sidebar ul a {
            display: flex;
            align-items: center;
            gap: 0.8rem;
            padding: 0.7rem 1rem;
            border-radius: 8px;
            color: #333333;
            text-decoration: none;
            transition: all 0.3s ease;
            font-weight: 500;
        }
        
        .sidebar ul a:hover {
            background: #f8f8f8;
        }
        
        .sidebar ul a.active {
            background: #1a1a1a;
            color: #ffffff;
        }
        
        .sidebar ul a i {
            width: 20px;
            text-align: center;
        }
        
        .sidebar .logout-btn {
            margin-top: 2rem;
            padding-top: 1rem;
            border-top: 1px solid #e5e7eb;
        }
        
        .sidebar .logout-btn a {
            color: #dc2626;
        }
        
        .sidebar .logout-btn a:hover {
            background: #fef2f2;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 2rem;
            flex: 1;
        }
        
        .main-content .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #e5e7eb;
        }
        
        .main-content .header h1 {
            font-weight: 700;
            font-size: 1.8rem;
            color: #1a1a1a;
        }
        
        .btn {
            display: inline-block;
            padding: 0.6rem 1.5rem;
            border-radius: 8px;
            text-decoration: none;
            font-family: 'Baloo 2', sans-serif;
            font-weight: 600;
            font-size: 0.95rem;
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
            text-align: center;
        }
        
        .btn-primary {
            background: #1a1a1a;
            color: #ffffff;
        }
        
        .btn-primary:hover {
            background: #333333;
        }
        
        .btn-secondary {
            background: #ffffff;
            color: #1a1a1a;
            border: 1px solid #e5e7eb;
        }
        
        .btn-secondary:hover {
            background: #f8f8f8;
        }
        
        .btn-sm {
            padding: 0.3rem 0.8rem;
            font-size: 0.8rem;
        }
        
        .alert-success {
            background: #d1fae5;
            color: #065f46;
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1rem;
            border: 1px solid #a7f3d0;
        }
        
        .alert-info {
            background: #e0f2fe;
            color: #0369a1;
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1rem;
            border: 1px solid #bae6fd;
        }
        
        .order-card {
            background: #ffffff;
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            border: 1px solid #e5e7eb;
            transition: all 0.3s ease;
        }
        
        .order-card:hover {
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
        }
        
        .order-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
            margin-bottom: 1rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #e5e7eb;
        }
        
        .order-id {
            font-weight: 700;
            font-size: 1.1rem;
            color: #1a1a1a;
        }
        
        .order-date {
            color: #6b7280;
            font-size: 0.9rem;
        }
        
        .status-badge {
            display: inline-block;
            padding: 0.3rem 1rem;
            border-radius: 20px;
            font-weight: 600;
            font-size: 0.85rem;
        }
        
        .status-pending {
            background: #fef3c7;
            color: #92400e;
        }
        
        .status-processing {
            background: #dbeafe;
            color: #1e40af;
        }
        
        .status-shipped {
            background: #d1fae5;
            color: #065f46;
        }
        
        .status-delivered {
            background: #d1fae5;
            color: #065f46;
        }
        
        .status-cancelled {
            background: #fee2e2;
            color: #991b1b;
        }
        
        .order-details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 1rem;
        }
        
        .order-details .label {
            color: #6b7280;
            font-size: 0.85rem;
            font-weight: 500;
        }
        
        .order-details .value {
            font-weight: 600;
            color: #1a1a1a;
        }
        
        .order-total {
            font-size: 1.3rem;
            font-weight: 800;
            color: #1a1a1a;
        }
        
        .order-actions {
            margin-top: 1rem;
            padding-top: 1rem;
            border-top: 1px solid #e5e7eb;
            display: flex;
            gap: 0.5rem;
            align-items: center;
            flex-wrap: wrap;
        }
        
        .order-actions select {
            padding: 0.5rem 1rem;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            font-family: 'Baloo 2', sans-serif;
            font-size: 0.95rem;
            background: #ffffff;
            color: #1a1a1a;
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem;
            background: #ffffff;
            border-radius: 12px;
            border: 1px solid #e5e7eb;
        }
        
        .empty-state i {
            font-size: 3rem;
            color: #9ca3af;
            margin-bottom: 1rem;
        }
        
        .empty-state h3 {
            font-weight: 600;
            color: #1a1a1a;
        }
        
        .empty-state p {
            color: #6b7280;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 200px;
                padding: 1rem;
            }
            .main-content {
                margin-left: 200px;
                padding: 1rem;
            }
        }
        
        @media (max-width: 576px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                border-right: none;
                border-bottom: 1px solid #e5e7eb;
                padding: 1rem;
            }
            .main-content {
                margin-left: 0;
                padding: 1rem;
            }
            .order-header {
                flex-direction: column;
                text-align: center;
            }
            .order-details {
                grid-template-columns: 1fr;
                text-align: center;
            }
            .order-actions {
                flex-direction: column;
            }
            .order-actions select {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <aside class="sidebar">
            <a href="dashboard.php" class="logo">SOKIVA <span>.</span></a>
            <ul>
                <li><a href="dashboard.php"><i class="fas fa-chart-line"></i> Dashboard</a></li>
                <li><a href="products.php"><i class="fas fa-box"></i> Products</a></li>
                <li><a href="orders.php" class="active"><i class="fas fa-shopping-bag"></i> Orders</a></li>
                <li class="logout-btn"><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </aside>
        
        <main class="main-content">
            <div class="header">
                <h1><i class="fas fa-shopping-bag"></i> Manage Orders</h1>
            </div>
            
            <?php if (isset($_GET['updated'])): ?>
            <div class="alert-success">
                <i class="fas fa-check-circle"></i> Order status updated successfully!
            </div>
            <?php endif; ?>
            
            <?php if (!$orders_exist): ?>
            <div class="alert-info">
                <i class="fas fa-info-circle"></i> No orders found. Orders will appear here once customers make purchases.
            </div>
            <?php endif; ?>
            
            <?php if (count($orders) > 0): ?>
                <?php foreach ($orders as $order): ?>
                <div class="order-card">
                    <div class="order-header">
                        <div>
                            <span class="order-id">Order #<?php echo $order['id']; ?></span>
                            <span class="order-date"><?php echo date('M d, Y H:i', strtotime($order['created_at'])); ?></span>
                        </div>
                        <span class="status-badge status-<?php echo strtolower($order['order_status'] ?? 'pending'); ?>">
                            <?php echo ucfirst($order['order_status'] ?? 'Pending'); ?>
                        </span>
                    </div>
                    
                    <div class="order-details">
                        <div>
                            <div class="label">Customer</div>
                            <div class="value"><?php echo htmlspecialchars($order['first_name'] . ' ' . $order['last_name']); ?></div>
                        </div>
                        <div>
                            <div class="label">Email</div>
                            <div class="value"><?php echo htmlspecialchars($order['email']); ?></div>
                        </div>
                        <div>
                            <div class="label">Phone</div>
                            <div class="value"><?php echo htmlspecialchars($order['phone']); ?></div>
                        </div>
                        <div>
                            <div class="label">Payment</div>
                            <div class="value"><?php echo str_replace('_', ' ', ucfirst($order['payment_method'])); ?></div>
                        </div>
                        <div>
                            <div class="label">Address</div>
                            <div class="value"><?php echo htmlspecialchars($order['address']); ?></div>
                        </div>
                        <div>
                            <div class="label">Total</div>
                            <div class="order-total">KES <?php echo number_format($order['total'] ?? 0); ?></div>
                        </div>
                    </div>
                    
                    <form method="POST" class="order-actions">
                        <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                        <select name="order_status">
                            <option value="pending" <?php echo ($order['order_status'] ?? 'pending') == 'pending' ? 'selected' : ''; ?>>Pending</option>
                            <option value="processing" <?php echo ($order['order_status'] ?? '') == 'processing' ? 'selected' : ''; ?>>Processing</option>
                            <option value="shipped" <?php echo ($order['order_status'] ?? '') == 'shipped' ? 'selected' : ''; ?>>Shipped</option>
                            <option value="delivered" <?php echo ($order['order_status'] ?? '') == 'delivered' ? 'selected' : ''; ?>>Delivered</option>
                            <option value="cancelled" <?php echo ($order['order_status'] ?? '') == 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                        </select>
                        <button type="submit" name="update_status" class="btn btn-primary btn-sm">
                            <i class="fas fa-save"></i> Update Status
                        </button>
                    </form>
                </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="empty-state">
                    <i class="fas fa-inbox"></i>
                    <h3>No orders yet</h3>
                    <p>Orders will appear here once customers make purchases.</p>
                </div>
            <?php endif; ?>
        </main>
    </div>
</body>
</html>