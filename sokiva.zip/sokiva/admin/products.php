<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

// Database connection
$host = 'localhost';
$dbname = 'sokiva';
$username = 'root';
$password = '';

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Handle delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    
    // Get image path to delete
    $stmt = $conn->prepare("SELECT image FROM products WHERE id = ?");
    $stmt->execute([$id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($product && !empty($product['image']) && file_exists('../uploads/products/' . $product['image'])) {
        unlink('../uploads/products/' . $product['image']);
    }
    
    $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
    $stmt->execute([$id]);
    header('Location: products.php?deleted=1');
    exit;
}

// Fetch all products
$stmt = $conn->query("SELECT * FROM products ORDER BY id DESC");
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);
$product_count = count($products);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Products - SOKIVA</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Baloo 2', sans-serif;
            background: #f8f8f8;
            color: #1a1a1a;
        }
        
        .admin-container {
            display: flex;
            min-height: 100vh;
        }
        
        .sidebar {
            width: 250px;
            background: #ffffff;
            border-right: 1px solid #e5e7eb;
            padding: 2rem 1.5rem;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }
        
        .sidebar .logo {
            font-family: 'Baloo 2', sans-serif;
            font-weight: 800;
            font-size: 1.5rem;
            letter-spacing: 3px;
            text-transform: uppercase;
            color: #1a1a1a;
            text-decoration: none;
            display: block;
            margin-bottom: 2rem;
        }
        
        .sidebar .logo span {
            color: #6b7280;
        }
        
        .sidebar ul {
            list-style: none;
        }
        
        .sidebar ul li {
            margin-bottom: 0.3rem;
        }
        
        .sidebar ul a {
            display: flex;
            align-items: center;
            gap: 0.8rem;
            padding: 0.7rem 1rem;
            border-radius: 8px;
            color: #333333;
            text-decoration: none;
            transition: all 0.3s ease;
            font-weight: 500;
        }
        
        .sidebar ul a:hover {
            background: #f8f8f8;
        }
        
        .sidebar ul a.active {
            background: #1a1a1a;
            color: #ffffff;
        }
        
        .sidebar ul a i {
            width: 20px;
            text-align: center;
        }
        
        .sidebar .logout-btn {
            margin-top: 2rem;
            padding-top: 1rem;
            border-top: 1px solid #e5e7eb;
        }
        
        .sidebar .logout-btn a {
            color: #dc2626;
        }
        
        .sidebar .logout-btn a:hover {
            background: #fef2f2;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 2rem;
            flex: 1;
        }
        
        .main-content .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #e5e7eb;
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        .main-content .header h1 {
            font-weight: 700;
            font-size: 1.8rem;
            color: #1a1a1a;
        }
        
        .btn {
            display: inline-block;
            padding: 0.6rem 1.5rem;
            border-radius: 8px;
            text-decoration: none;
            font-family: 'Baloo 2', sans-serif;
            font-weight: 600;
            font-size: 0.95rem;
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
            text-align: center;
        }
        
        .btn-primary {
            background: #1a1a1a;
            color: #ffffff;
        }
        
        .btn-primary:hover {
            background: #333333;
            transform: translateY(-2px);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
        }
        
        .btn-secondary {
            background: #ffffff;
            color: #1a1a1a;
            border: 1px solid #e5e7eb;
        }
        
        .btn-secondary:hover {
            background: #f8f8f8;
        }
        
        .btn-danger {
            background: #dc2626;
            color: #ffffff;
        }
        
        .btn-danger:hover {
            background: #b91c1c;
        }
        
        .btn-sm {
            padding: 0.3rem 0.8rem;
            font-size: 0.8rem;
        }
        
        .alert {
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1rem;
        }
        
        .alert-success {
            background: #d1fae5;
            color: #065f46;
            border: 1px solid #a7f3d0;
        }
        
        .table-container {
            background: #ffffff;
            border-radius: 12px;
            border: 1px solid #e5e7eb;
            overflow: hidden;
        }
        
        .table-container table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .table-container th {
            text-align: left;
            padding: 0.8rem 1rem;
            background: #f8f8f8;
            color: #1a1a1a;
            font-weight: 600;
            border-bottom: 1px solid #e5e7eb;
        }
        
        .table-container td {
            padding: 0.8rem 1rem;
            border-bottom: 1px solid #e5e7eb;
            color: #333333;
            vertical-align: middle;
        }
        
        .table-container tr:hover td {
            background: #fafafa;
        }
        
        .table-container .product-image-thumb {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
        }
        
        .table-container .product-image-placeholder {
            width: 60px;
            height: 60px;
            background: #f8f8f8;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #9ca3af;
            font-size: 1.5rem;
        }
        
        .table-container .actions {
            display: flex;
            gap: 0.5rem;
            flex-wrap: wrap;
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem;
            background: #ffffff;
            border-radius: 12px;
            border: 1px solid #e5e7eb;
        }
        
        .empty-state i {
            font-size: 3rem;
            color: #9ca3af;
            margin-bottom: 1rem;
        }
        
        .empty-state h3 {
            font-weight: 600;
            color: #1a1a1a;
        }
        
        .empty-state p {
            color: #6b7280;
        }
        
        .product-count {
            margin-bottom: 1rem;
            color: #6b7280;
        }
        
        .product-count strong {
            color: #1a1a1a;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 200px;
                padding: 1rem;
            }
            .main-content {
                margin-left: 200px;
                padding: 1rem;
            }
            .table-container {
                overflow-x: auto;
            }
        }
        
        @media (max-width: 576px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                border-right: none;
                border-bottom: 1px solid #e5e7eb;
                padding: 1rem;
            }
            .main-content {
                margin-left: 0;
                padding: 1rem;
            }
            .main-content .header {
                flex-direction: column;
                text-align: center;
            }
            .table-container table {
                font-size: 0.85rem;
            }
            .table-container th,
            .table-container td {
                padding: 0.5rem;
            }
            .btn-sm {
                padding: 0.2rem 0.5rem;
                font-size: 0.7rem;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <a href="dashboard.php" class="logo">SOKIVA <span>.</span></a>
            <ul>
                <li><a href="dashboard.php"><i class="fas fa-chart-line"></i> Dashboard</a></li>
                <li><a href="products.php" class="active"><i class="fas fa-box"></i> Products</a></li>
                <li><a href="orders.php"><i class="fas fa-shopping-bag"></i> Orders</a></li>
                <li><a href="messages.php"><i class="fas fa-envelope"></i> Messages</a></li>
                <li><a href="change_password.php"><i class="fas fa-key"></i> Change Password</a></li>
                <li class="logout-btn"><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </aside>
        
        <!-- Main Content -->
        <main class="main-content">
            <div class="header">
                <h1><i class="fas fa-box"></i> Manage Products</h1>
                <a href="add_product.php" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Add New Product
                </a>
            </div>
            
            <?php if (isset($_GET['deleted'])): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> Product deleted successfully!
            </div>
            <?php endif; ?>
            
            <?php if (isset($_GET['added'])): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> Product added successfully!
            </div>
            <?php endif; ?>
            
            <?php if (isset($_GET['updated'])): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> Product updated successfully!
            </div>
            <?php endif; ?>
            
            <?php if ($product_count > 0): ?>
            <div class="product-count">
                <strong><?php echo $product_count; ?></strong> products found
            </div>
            
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Image</th>
                            <th>ID</th>
                            <th>Product Name</th>
                            <th>Specs</th>
                            <th>Condition</th>
                            <th>Price</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($products as $product): ?>
                        <tr>
                            <td>
                                <?php if (!empty($product['image']) && file_exists('../uploads/products/' . $product['image'])): ?>
                                    <img src="../uploads/products/<?php echo $product['image']; ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="product-image-thumb">
                                <?php else: ?>
                                    <div class="product-image-placeholder">
                                        <i class="fas fa-laptop"></i>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td>#<?php echo $product['id']; ?></td>
                            <td><strong><?php echo htmlspecialchars($product['name']); ?></strong></td>
                            <td><?php echo htmlspecialchars($product['specs']); ?></td>
                            <td><?php echo htmlspecialchars($product['condition']); ?></td>
                            <td><strong>KES <?php echo number_format($product['price']); ?></strong></td>
                            <td>
                                <div class="actions">
                                    <a href="edit_product.php?id=<?php echo $product['id']; ?>" class="btn btn-secondary btn-sm">
                                        <i class="fas fa-edit"></i> Edit
                                    </a>
                                    <a href="products.php?delete=<?php echo $product['id']; ?>" 
                                       class="btn btn-danger btn-sm" 
                                       onclick="return confirm('Are you sure you want to delete this product?')">
                                        <i class="fas fa-trash"></i> Delete
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="empty-state">
                <i class="fas fa-box-open"></i>
                <h3>No products found</h3>
                <p>Click "Add New Product" to create your first product.</p>
                <a href="add_product.php" class="btn btn-primary" style="margin-top: 1rem;">
                    <i class="fas fa-plus"></i> Add New Product
                </a>
            </div>
            <?php endif; ?>
        </main>
    </div>
</body>
</html>