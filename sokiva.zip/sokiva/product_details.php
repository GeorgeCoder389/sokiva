<!-- Product Image -->
<div class="product-image-large">
    <?php if (!empty($product['image']) && file_exists('uploads/products/' . $product['image'])): ?>
        <img src="uploads/products/<?php echo $product['image']; ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" style="width:100%; height:100%; object-fit:contain; max-height:400px;">
    <?php else: ?>
        <i class="fas fa-laptop"></i>
    <?php endif; ?>
</div>