<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$host = 'localhost';
$dbname = 'sokiva';
$username = 'root';
$password = '';

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Initialize products as empty array
$products = array();

// Get products
try {
    $stmt = $conn->query("SELECT * FROM products ORDER BY id DESC LIMIT 6");
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $products = array();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SOKIVA - Find Your Laptop</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* ===== RESET ===== */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Baloo 2', sans-serif;
            background: #ffffff;
            color: #1a1a1a;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 1.5rem;
        }
        
        /* ===== HEADER ===== */
        .header {
            background: #ffffff;
            padding: 0.8rem 2rem;
            border-bottom: 1px solid #e5e7eb;
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        
        .header-container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        .logo {
            font-family: 'Baloo 2', sans-serif;
            font-weight: 800;
            font-size: 1.6rem;
            letter-spacing: 3px;
            color: #1a1a1a;
            text-transform: uppercase;
            text-decoration: none;
        }
        
        .logo span {
            color: #6b7280;
        }
        
        .tagline {
            color: #6b7280;
            font-size: 0.85rem;
            font-weight: 400;
            display: none;
        }
        
        @media (min-width: 768px) {
            .tagline {
                display: inline;
            }
        }
        
        .nav-menu {
            display: flex;
            align-items: center;
            gap: 2rem;
            list-style: none;
        }
        
        .nav-menu a {
            color: #333333;
            text-decoration: none;
            font-weight: 500;
            font-size: 1rem;
            transition: all 0.3s ease;
            position: relative;
        }
        
        .nav-menu a::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 0;
            height: 2px;
            background: #1a1a1a;
            transition: all 0.3s ease;
        }
        
        .nav-menu a:hover {
            color: #1a1a1a;
        }
        
        .nav-menu a:hover::after {
            width: 100%;
        }
        
        .nav-menu a.active {
            color: #1a1a1a;
            font-weight: 600;
        }
        
        .nav-menu a.active::after {
            width: 100%;
        }
        
        .cart-icon {
            position: relative;
            font-size: 1.2rem;
            color: #333333;
        }
        
        .cart-icon:hover {
            color: #1a1a1a;
        }
        
        .cart-badge {
            position: absolute;
            top: -8px;
            right: -10px;
            background: #1a1a1a;
            color: white;
            font-size: 0.65rem;
            font-weight: 700;
            width: 18px;
            height: 18px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .hamburger {
            display: none;
            flex-direction: column;
            gap: 5px;
            cursor: pointer;
            background: none;
            border: none;
            padding: 0.3rem;
        }
        
        .hamburger span {
            width: 25px;
            height: 3px;
            background: #1a1a1a;
            border-radius: 3px;
            transition: all 0.3s ease;
        }
        
        @media (max-width: 768px) {
            .hamburger {
                display: flex;
            }
            
            .nav-menu {
                display: none;
                flex-direction: column;
                width: 100%;
                padding: 1rem 0;
                border-top: 1px solid #e5e7eb;
                gap: 0.8rem;
            }
            
            .nav-menu.open {
                display: flex;
            }
            
            .nav-menu a {
                font-size: 1.1rem;
                padding: 0.5rem 0;
            }
        }
        
        /* ===== HERO ===== */
        .hero {
            background: #f8f8f8;
            padding: 3rem 2rem;
            text-align: center;
            border-bottom: 1px solid #e5e7eb;
            margin-bottom: 2rem;
        }
        
        .hero h1 {
            font-size: 2.5rem;
            font-weight: 800;
            letter-spacing: 1px;
            margin-bottom: 0.5rem;
            color: #1a1a1a;
        }
        
        .hero p {
            font-size: 1.1rem;
            font-weight: 400;
            color: #6b7280;
            max-width: 600px;
            margin: 0 auto;
        }
        
        @media (max-width: 768px) {
            .hero h1 {
                font-size: 1.8rem;
            }
            .hero p {
                font-size: 0.95rem;
            }
        }
        
        /* ===== BUTTONS ===== */
        .btn {
            display: inline-block;
            padding: 0.7rem 1.8rem;
            border-radius: 8px;
            text-decoration: none;
            font-family: 'Baloo 2', sans-serif;
            font-weight: 600;
            font-size: 0.95rem;
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
            text-align: center;
        }
        
        .btn-primary {
            background: #1a1a1a;
            color: #ffffff;
        }
        
        .btn-primary:hover {
            background: #333333;
            transform: translateY(-2px);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
        }
        
        .btn-secondary {
            background: #ffffff;
            color: #1a1a1a;
            border: 1px solid #e5e7eb;
        }
        
        .btn-secondary:hover {
            background: #f8f8f8;
            border-color: #6b7280;
        }
        
        /* ===== SEARCH ===== */
        .search-bar {
            display: flex;
            gap: 1rem;
            max-width: 600px;
            margin: 0 auto 2rem;
        }
        
        .search-bar input {
            flex: 1;
            padding: 0.7rem 1.5rem;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            font-family: 'Baloo 2', sans-serif;
            font-size: 1rem;
            outline: none;
            transition: all 0.3s ease;
            background: #ffffff;
            color: #1a1a1a;
        }
        
        .search-bar input:focus {
            border-color: #1a1a1a;
            box-shadow: 0 0 0 3px rgba(0, 0, 0, 0.05);
        }
        
        /* ===== FILTERS ===== */
        .filter-section {
            background: #ffffff;
            padding: 1.2rem 1.5rem;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
            margin-bottom: 2rem;
            border: 1px solid #e5e7eb;
        }
        
        .filter-section h3 {
            font-weight: 600;
            font-size: 1rem;
            margin-bottom: 0.8rem;
            color: #333333;
        }
        
        .filter-options {
            display: flex;
            flex-wrap: wrap;
            gap: 0.5rem;
        }
        
        .filter-btn {
            padding: 0.4rem 1.2rem;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            background: #ffffff;
            color: #333333;
            font-family: 'Baloo 2', sans-serif;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 0.9rem;
        }
        
        .filter-btn:hover {
            background: #f8f8f8;
            border-color: #6b7280;
        }
        
        .filter-btn.active {
            background: #1a1a1a;
            color: #ffffff;
            border-color: #1a1a1a;
        }
        
        /* ===== PRODUCT CARDS ===== */
        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 1.5rem;
            padding: 1rem 0;
        }
        
        .product-card {
            background: #ffffff;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease;
            border: 1px solid #e5e7eb;
        }
        
        .product-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1);
        }
        
        .product-image {
            width: 100%;
            height: 200px;
            background: #f8f8f8;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3.5rem;
            color: #6b7280;
            border-bottom: 1px solid #e5e7eb;
            overflow: hidden;
        }
        
        .product-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .product-info {
            padding: 1.2rem 1.2rem 1.5rem;
        }
        
        .product-title {
            font-weight: 700;
            font-size: 1.1rem;
            color: #1a1a1a;
            margin-bottom: 0.2rem;
        }
        
        .product-specs {
            color: #6b7280;
            font-weight: 400;
            font-size: 0.85rem;
            margin-bottom: 0.3rem;
        }
        
        .product-condition {
            display: inline-block;
            background: #f8f8f8;
            color: #333333;
            padding: 0.15rem 0.8rem;
            border-radius: 20px;
            font-weight: 500;
            font-size: 0.75rem;
            margin-bottom: 0.6rem;
        }
        
        .product-price {
            font-weight: 800;
            font-size: 1.3rem;
            color: #1a1a1a;
        }
        
        .product-actions {
            display: flex;
            gap: 0.8rem;
            margin-top: 0.8rem;
        }
        
        .product-actions .btn {
            flex: 1;
            font-size: 0.85rem;
            padding: 0.5rem 1rem;
            text-align: center;
        }
        
        .product-actions .btn-secondary {
            background: #f8f8f8;
        }
        
        .product-actions .btn-secondary:hover {
            background: #1a1a1a;
            color: #ffffff;
            border-color: #1a1a1a;
        }
        
        /* ===== SECTION TITLE ===== */
        .section-title {
            font-weight: 700;
            font-size: 1.8rem;
            color: #1a1a1a;
            margin-bottom: 1.5rem;
            text-align: center;
        }
        
        /* ===== EMPTY STATE ===== */
        .empty-state {
            grid-column: 1 / -1;
            text-align: center;
            padding: 3rem;
            background: #ffffff;
            border-radius: 12px;
            border: 1px solid #e5e7eb;
        }
        
        .empty-state i {
            font-size: 3rem;
            color: #9ca3af;
            margin-bottom: 1rem;
        }
        
        .empty-state h3 {
            font-weight: 600;
            color: #1a1a1a;
        }
        
        .empty-state p {
            color: #6b7280;
        }
        
        /* ===== ASK SECTION ===== */
        .ask-section {
            background: #f8f8f8;
            padding: 2.5rem;
            border-radius: 12px;
            text-align: center;
            margin-top: 2rem;
            border: 1px solid #e5e7eb;
        }
        
        .ask-section h3 {
            font-weight: 700;
            font-size: 1.3rem;
            color: #1a1a1a;
        }
        
        .ask-section p {
            color: #6b7280;
            font-size: 1rem;
            margin: 0.5rem 0 1.5rem;
        }
        
        /* ===== FOOTER ===== */
        .footer {
            background: #f8f8f8;
            padding: 2.5rem 2rem 1.5rem;
            margin-top: 2rem;
            border-top: 1px solid #e5e7eb;
        }
        
        .footer-container {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 2rem;
        }
        
        .footer h4 {
            font-weight: 700;
            font-size: 1rem;
            margin-bottom: 0.8rem;
            color: #1a1a1a;
        }
        
        .footer ul {
            list-style: none;
        }
        
        .footer ul li {
            margin-bottom: 0.4rem;
        }
        
        .footer ul a {
            color: #6b7280;
            text-decoration: none;
            transition: all 0.3s ease;
            font-size: 0.9rem;
        }
        
        .footer ul a:hover {
            color: #1a1a1a;
        }
        
        .footer-bottom {
            text-align: center;
            padding-top: 1.5rem;
            margin-top: 1.5rem;
            border-top: 1px solid #e5e7eb;
            color: #9ca3af;
            font-size: 0.85rem;
        }
        
        .footer-logo {
            font-weight: 800;
            font-size: 1.3rem;
            letter-spacing: 3px;
            text-transform: uppercase;
            color: #1a1a1a;
        }
        
        .footer-logo span {
            color: #6b7280;
        }
        
        /* ===== WHATSAPP FLOAT ===== */
        .whatsapp-float {
            position: fixed;
            bottom: 30px;
            right: 30px;
            background: #25D366;
            color: white;
            width: 55px;
            height: 55px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            box-shadow: 0 4px 20px rgba(37, 211, 102, 0.3);
            transition: all 0.3s ease;
            z-index: 999;
            text-decoration: none;
        }
        
        .whatsapp-float:hover {
            transform: scale(1.1);
            box-shadow: 0 8px 30px rgba(37, 211, 102, 0.4);
        }
        
        /* ===== RESPONSIVE ===== */
        @media (max-width: 576px) {
            .product-grid {
                grid-template-columns: 1fr;
            }
            .footer-container {
                grid-template-columns: 1fr;
                text-align: center;
            }
            .search-bar {
                flex-direction: column;
            }
            .btn {
                padding: 0.5rem 1.2rem;
                font-size: 0.85rem;
            }
        }
    </style>
</head>
<body>
    <!-- ===== HEADER ===== -->
    <header class="header">
        <div class="header-container">
            <a href="/sokiva/" class="logo">SOKIVA <span>.</span></a>
            <span class="tagline">Access your desire.</span>
            
            <button class="hamburger" id="hamburger" aria-label="Toggle menu">
                <span></span>
                <span></span>
                <span></span>
            </button>
            
            <nav>
                <ul class="nav-menu" id="navMenu">
                    <li><a href="/sokiva/" class="active">Home</a></li>
                    <li><a href="/sokiva/shop.php">All Laptops</a></li>
                    <li><a href="/sokiva/contact.php">Contact</a></li>
                    <li>
                        <a href="/sokiva/cart.php" class="cart-icon">
                            <i class="fas fa-shopping-cart"></i>
                            <?php
                            $cart_count = isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0;
                            if ($cart_count > 0) {
                                echo '<span class="cart-badge">' . $cart_count . '</span>';
                            }
                            ?>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </header>
    
    <script>
        document.getElementById('hamburger').addEventListener('click', function() {
            document.getElementById('navMenu').classList.toggle('open');
        });
    </script>

    <!-- ===== HERO ===== -->
    <section class="hero">
        <div class="container">
            <h1>Find Your <span style="color: #1a1a1a;">Laptop</span></h1>
            <p>Find your laptop. Good laptops. Clear prices. Access them through Sokiva.</p>
            <div style="margin-top: 1.5rem;">
                <a href="/sokiva/shop.php" class="btn btn-primary">Shop Now</a>
                <a href="/sokiva/contact.php" class="btn btn-secondary" style="margin-left: 1rem;">Need Help?</a>
            </div>
        </div>
    </section>

    <!-- ===== MAIN CONTENT ===== -->
    <main class="container" style="padding: 0 1.5rem 3rem;">
        
        <!-- ===== SEARCH ===== -->
        <div class="search-bar">
            <input type="text" id="searchInput" placeholder="Search laptops..." onkeyup="searchProducts()">
            <button class="btn btn-primary" onclick="searchProducts()">
                <i class="fas fa-search"></i> Search
            </button>
        </div>
        
        <!-- ===== FILTERS ===== -->
        <div class="filter-section">
            <h3><i class="fas fa-tag"></i> Shop by price</h3>
            <div class="filter-options">
                <button class="filter-btn active" onclick="filterProducts('all', this)">All</button>
                <button class="filter-btn" onclick="filterProducts('under30k', this)">Under 30K</button>
                <button class="filter-btn" onclick="filterProducts('30to60k', this)">30K – 60K</button>
                <button class="filter-btn" onclick="filterProducts('over60k', this)">60K+</button>
            </div>
        </div>
        
        <!-- ===== PRODUCTS ===== -->
        <h2 class="section-title">Available Laptops</h2>
        <div class="product-grid" id="productGrid">
            <?php if (count($products) > 0): ?>
                <?php foreach ($products as $product): ?>
                <div class="product-card" data-price="<?php echo $product['price']; ?>">
                    <div class="product-image">
                        <?php if (!empty($product['image']) && file_exists('uploads/products/' . $product['image'])): ?>
                            <img src="uploads/products/<?php echo $product['image']; ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                        <?php else: ?>
                            <i class="fas fa-laptop"></i>
                        <?php endif; ?>
                    </div>
                    <div class="product-info">
                        <h3 class="product-title"><?php echo htmlspecialchars($product['name']); ?></h3>
                        <p class="product-specs"><?php echo htmlspecialchars($product['specs']); ?></p>
                        <span class="product-condition"><?php echo htmlspecialchars($product['condition']); ?></span>
                        <div class="product-price">KES <?php echo number_format($product['price']); ?></div>
                        <div class="product-actions">
                            <a href="/sokiva/product_details.php?id=<?php echo $product['id']; ?>" class="btn btn-secondary">View</a>
                            <button class="btn btn-primary" onclick="addToCart(<?php echo $product['id']; ?>)">
                                <i class="fas fa-cart-plus"></i>
                            </button>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="empty-state">
                    <i class="fas fa-box-open"></i>
                    <h3>No products available</h3>
                    <p>Please check back later for new arrivals.</p>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- ===== ASK SOKIVA ===== -->
        <div class="ask-section">
            <h3>Can't find the laptop you're looking for?</h3>
            <p>Tell us what you need and we'll help you find it.</p>
            <a href="/sokiva/contact.php" class="btn btn-primary">
                <i class="fas fa-question-circle"></i> Ask Sokiva
            </a>
        </div>
    </main>

    <!-- ===== FOOTER ===== -->
    <footer class="footer">
        <div class="footer-container">
            <div>
                <div class="footer-logo">SOKIVA <span>.</span></div>
                <p style="margin-top: 0.3rem; color: #6b7280; font-size: 0.9rem;">Access your desire.</p>
            </div>
            <div>
                <h4>Quick Links</h4>
                <ul>
                    <li><a href="/sokiva/">Home</a></li>
                    <li><a href="/sokiva/shop.php">All Laptops</a></li>
                    <li><a href="/sokiva/contact.php">Contact</a></li>
                    <li><a href="/sokiva/about.php">About Us</a></li>
                </ul>
            </div>
            <div>
                <h4>Support</h4>
                <ul>
                    <li><a href="/sokiva/contact.php">Help Center</a></li>
                    <li><a href="/sokiva/privacy.php">Privacy Policy</a></li>
                    <li><a href="/sokiva/terms.php">Terms & Conditions</a></li>
                </ul>
            </div>
            <div>
                <h4>Connect With Us</h4>
                <ul>
                    <li><a href="https://wa.me/254793019606" target="_blank"><i class="fab fa-whatsapp"></i> WhatsApp</a></li>
                    <li><a href="https://www.instagram.com/sokivagadgets/" target="_blank"><i class="fab fa-instagram"></i> Instagram</a></li>
                    <li><a href="https://www.tiktok.com/@sokivagadgets" target="_blank"><i class="fab fa-tiktok"></i> TikTok</a></li>
                    <li><a href="https://whatsapp.com/channel/0029VbCfNcUHgZWk5yLEC03x" target="_blank"><i class="fab fa-whatsapp"></i> WhatsApp Channel</a></li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            &copy; <?php echo date('Y'); ?> SOKIVA. All rights reserved.
        </div>
    </footer>

    <!-- WhatsApp Float -->
    <a href="https://wa.me/254793019606?text=Hello%20Sokiva%2C%20I%20need%20help%20finding%20a%20laptop" 
       class="whatsapp-float" 
       target="_blank" 
       aria-label="Chat on WhatsApp">
        <i class="fab fa-whatsapp"></i>
    </a>

    <script>
        // Search functionality
        function searchProducts() {
            const input = document.getElementById('searchInput').value.toLowerCase();
            const cards = document.querySelectorAll('.product-card');
            
            cards.forEach(function(card) {
                const title = card.querySelector('.product-title');
                const specs = card.querySelector('.product-specs');
                let match = false;
                
                if (title) {
                    match = title.textContent.toLowerCase().includes(input);
                }
                if (!match && specs) {
                    match = specs.textContent.toLowerCase().includes(input);
                }
                
                card.style.display = match ? '' : 'none';
            });
        }

        // Filter by price
        function filterProducts(filter, button) {
            const cards = document.querySelectorAll('.product-card');
            const buttons = document.querySelectorAll('.filter-btn');
            
            buttons.forEach(function(btn) {
                btn.classList.remove('active');
            });
            button.classList.add('active');
            
            cards.forEach(function(card) {
                const price = parseInt(card.dataset.price);
                let show = false;
                
                switch(filter) {
                    case 'all':
                        show = true;
                        break;
                    case 'under30k':
                        show = price < 30000;
                        break;
                    case '30to60k':
                        show = price >= 30000 && price <= 60000;
                        break;
                    case 'over60k':
                        show = price > 60000;
                        break;
                    default:
                        show = true;
                }
                
                card.style.display = show ? '' : 'none';
            });
        }

        // Add to cart function
        function addToCart(productId) {
            if (!productId) {
                alert('Invalid product ID');
                return;
            }
            
            var xhr = new XMLHttpRequest();
            xhr.open('POST', '/sokiva/add_to_cart.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onload = function() {
                if (this.status === 200) {
                    try {
                        var response = JSON.parse(this.responseText);
                        if (response.success) {
                            alert('Product added to cart!');
                            location.reload();
                        } else {
                            alert('Error adding to cart. Please try again.');
                        }
                    } catch(e) {
                        alert('Error adding to cart. Please try again.');
                    }
                } else {
                    alert('Error adding to cart. Please try again.');
                }
            };
            xhr.send('product_id=' + productId);
        }
    </script>
</body>
</html>