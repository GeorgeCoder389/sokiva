<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db_connect.php';

$orderNumber = $_GET['order'] ?? '';
$stmt = $pdo->prepare("SELECT * FROM orders WHERE order_number = ?");
$stmt->execute([$orderNumber]);
$order = $stmt->fetch();

if (!$order) {
    header('Location: ' . BASE_URL . '/index.php');
    exit;
}

$stmt2 = $pdo->prepare("SELECT * FROM order_items WHERE order_id = ?");
$stmt2->execute([$order['id']]);
$items = $stmt2->fetchAll();

$waMessage = "Hi SOKIVA, I've just placed order {$order['order_number']}. Please confirm my order.";
$pageTitle = 'Order Confirmed — SOKIVA';
require_once __DIR__ . '/includes/header.php';
?>

<div class="confirmation-box">
    <div class="check-icon">&#10004;</div>
    <h1>Order Placed!</h1>
    <p class="muted">Order Number: <strong><?= htmlspecialchars($order['order_number']) ?></strong></p>
    <p class="muted">We'll reach out via phone or WhatsApp to confirm delivery details.</p>

    <div class="order-summary-list">
        <?php foreach ($items as $item): ?>
            <div class="item-row">
                <span><?= htmlspecialchars($item['product_name']) ?> × <?= $item['quantity'] ?></span>
                <span><?= CURRENCY ?> <?= number_format($item['subtotal'], 2) ?></span>
            </div>
        <?php endforeach; ?>
        <div class="item-row" style="font-weight:600; border-bottom:none;">
            <span>Total</span>
            <span><?= CURRENCY ?> <?= number_format($order['total_amount'], 2) ?></span>
        </div>
    </div>

    <div class="product-actions" style="justify-content:center;">
        <a href="https://wa.me/<?= WHATSAPP_NUMBER ?>?text=<?= urlencode($waMessage) ?>" target="_blank" rel="noopener" class="btn btn-primary">Confirm on WhatsApp</a>
        <a href="<?= BASE_URL ?>/shop.php" class="btn btn-secondary">Continue Shopping</a>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>