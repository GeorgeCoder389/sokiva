<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

// Database connection
$host = 'localhost';
$dbname = 'sokiva';
$username = 'root';
$password = '';

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

$order_id = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;

// Get order details
$order = null;
$order_items = [];

if ($order_id > 0) {
    try {
        // Check if orders table exists
        $table_check = $conn->query("SHOW TABLES LIKE 'orders'")->rowCount();
        if ($table_check > 0) {
            $stmt = $conn->prepare("SELECT * FROM orders WHERE id = ?");
            $stmt->execute([$order_id]);
            $order = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($order) {
                // Get order items
                $stmt = $conn->prepare("SELECT * FROM order_items WHERE order_id = ?");
                $stmt->execute([$order_id]);
                $order_items = $stmt->fetchAll(PDO::FETCH_ASSOC);
            }
        }
    } catch(PDOException $e) {
        // Order not found
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Success - SOKIVA</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Baloo 2', sans-serif;
            background: #ffffff;
            color: #1a1a1a;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 1.5rem;
        }
        
        /* ===== HEADER ===== */
        .header {
            background: #ffffff;
            padding: 0.8rem 2rem;
            border-bottom: 1px solid #e5e7eb;
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        
        .header-container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        .logo {
            font-family: 'Baloo 2', sans-serif;
            font-weight: 800;
            font-size: 1.6rem;
            letter-spacing: 3px;
            color: #1a1a1a;
            text-transform: uppercase;
            text-decoration: none;
        }
        
        .logo span {
            color: #6b7280;
        }
        
        .tagline {
            color: #6b7280;
            font-size: 0.85rem;
            font-weight: 400;
            display: none;
        }
        
        @media (min-width: 768px) {
            .tagline {
                display: inline;
            }
        }
        
        .nav-menu {
            display: flex;
            align-items: center;
            gap: 2rem;
            list-style: none;
        }
        
        .nav-menu a {
            color: #333333;
            text-decoration: none;
            font-weight: 500;
            font-size: 1rem;
            transition: all 0.3s ease;
            position: relative;
        }
        
        .nav-menu a::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 0;
            height: 2px;
            background: #1a1a1a;
            transition: all 0.3s ease;
        }
        
        .nav-menu a:hover {
            color: #1a1a1a;
        }
        
        .nav-menu a:hover::after {
            width: 100%;
        }
        
        .nav-menu a.active {
            color: #1a1a1a;
            font-weight: 600;
        }
        
        .nav-menu a.active::after {
            width: 100%;
        }
        
        .cart-icon {
            position: relative;
            font-size: 1.2rem;
            color: #333333;
        }
        
        .cart-icon:hover {
            color: #1a1a1a;
        }
        
        .cart-badge {
            position: absolute;
            top: -8px;
            right: -10px;
            background: #1a1a1a;
            color: white;
            font-size: 0.65rem;
            font-weight: 700;
            width: 18px;
            height: 18px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .hamburger {
            display: none;
            flex-direction: column;
            gap: 5px;
            cursor: pointer;
            background: none;
            border: none;
            padding: 0.3rem;
        }
        
        .hamburger span {
            width: 25px;
            height: 3px;
            background: #1a1a1a;
            border-radius: 3px;
            transition: all 0.3s ease;
        }
        
        @media (max-width: 768px) {
            .hamburger {
                display: flex;
            }
            
            .nav-menu {
                display: none;
                flex-direction: column;
                width: 100%;
                padding: 1rem 0;
                border-top: 1px solid #e5e7eb;
                gap: 0.8rem;
            }
            
            .nav-menu.open {
                display: flex;
            }
            
            .nav-menu a {
                font-size: 1.1rem;
                padding: 0.5rem 0;
            }
        }
        
        /* ===== SUCCESS PAGE ===== */
        .success-container {
            padding: 2rem 0 3rem;
        }
        
        .success-card {
            background: #ffffff;
            border-radius: 16px;
            padding: 3rem;
            max-width: 700px;
            margin: 0 auto;
            text-align: center;
            border: 1px solid #e5e7eb;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.08);
        }
        
        .success-card .icon {
            font-size: 5rem;
            color: #22c55e;
            margin-bottom: 1rem;
        }
        
        .success-card h1 {
            font-weight: 800;
            font-size: 2rem;
            color: #1a1a1a;
            margin-bottom: 0.5rem;
        }
        
        .success-card p {
            color: #6b7280;
            font-size: 1.1rem;
            margin-bottom: 0.5rem;
        }
        
        .success-card .order-id {
            background: #f8f8f8;
            padding: 0.5rem 1.5rem;
            border-radius: 8px;
            display: inline-block;
            font-weight: 600;
            color: #1a1a1a;
            margin: 0.5rem 0 1rem;
            font-size: 1.1rem;
        }
        
        .order-details-box {
            background: #f8f8f8;
            border-radius: 12px;
            padding: 1.5rem;
            margin: 1.5rem 0;
            text-align: left;
        }
        
        .order-details-box .row {
            display: flex;
            justify-content: space-between;
            padding: 0.5rem 0;
            border-bottom: 1px solid #e5e7eb;
        }
        
        .order-details-box .row:last-child {
            border-bottom: none;
        }
        
        .order-details-box .label {
            color: #6b7280;
            font-weight: 500;
        }
        
        .order-details-box .value {
            font-weight: 600;
            color: #1a1a1a;
        }
        
        .order-details-box .status-badge {
            display: inline-block;
            padding: 0.2rem 1rem;
            border-radius: 20px;
            font-weight: 600;
            font-size: 0.85rem;
        }
        
        .status-pending {
            background: #fef3c7;
            color: #92400e;
        }
        
        .status-processing {
            background: #dbeafe;
            color: #1e40af;
        }
        
        .status-shipped {
            background: #d1fae5;
            color: #065f46;
        }
        
        .status-delivered {
            background: #d1fae5;
            color: #065f46;
        }
        
        .status-cancelled {
            background: #fee2e2;
            color: #991b1b;
        }
        
        .btn {
            display: inline-block;
            padding: 0.7rem 1.8rem;
            border-radius: 8px;
            text-decoration: none;
            font-family: 'Baloo 2', sans-serif;
            font-weight: 600;
            font-size: 0.95rem;
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
            text-align: center;
        }
        
        .btn-primary {
            background: #1a1a1a;
            color: #ffffff;
        }
        
        .btn-primary:hover {
            background: #333333;
            transform: translateY(-2px);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
        }
        
        .btn-secondary {
            background: #ffffff;
            color: #1a1a1a;
            border: 1px solid #e5e7eb;
        }
        
        .btn-secondary:hover {
            background: #f8f8f8;
        }
        
        .actions {
            display: flex;
            gap: 1rem;
            justify-content: center;
            flex-wrap: wrap;
            margin-top: 1.5rem;
        }
        
        /* ===== FOOTER ===== */
        .footer {
            background: #f8f8f8;
            padding: 2.5rem 2rem 1.5rem;
            margin-top: 2rem;
            border-top: 1px solid #e5e7eb;
        }
        
        .footer-container {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 2rem;
        }
        
        .footer h4 {
            font-weight: 700;
            font-size: 1rem;
            margin-bottom: 0.8rem;
            color: #1a1a1a;
        }
        
        .footer ul {
            list-style: none;
        }
        
        .footer ul li {
            margin-bottom: 0.4rem;
        }
        
        .footer ul a {
            color: #6b7280;
            text-decoration: none;
            transition: all 0.3s ease;
            font-size: 0.9rem;
        }
        
        .footer ul a:hover {
            color: #1a1a1a;
        }
        
        .footer-bottom {
            text-align: center;
            padding-top: 1.5rem;
            margin-top: 1.5rem;
            border-top: 1px solid #e5e7eb;
            color: #9ca3af;
            font-size: 0.85rem;
        }
        
        .footer-logo {
            font-weight: 800;
            font-size: 1.3rem;
            letter-spacing: 3px;
            text-transform: uppercase;
            color: #1a1a1a;
        }
        
        .footer-logo span {
            color: #6b7280;
        }
        
        .whatsapp-float {
            position: fixed;
            bottom: 30px;
            right: 30px;
            background: #25D366;
            color: white;
            width: 55px;
            height: 55px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            box-shadow: 0 4px 20px rgba(37, 211, 102, 0.3);
            transition: all 0.3s ease;
            z-index: 999;
            text-decoration: none;
        }
        
        .whatsapp-float:hover {
            transform: scale(1.1);
            box-shadow: 0 8px 30px rgba(37, 211, 102, 0.4);
        }
        
        @media (max-width: 576px) {
            .success-card {
                padding: 2rem;
            }
            .success-card h1 {
                font-size: 1.5rem;
            }
            .actions {
                flex-direction: column;
            }
            .actions .btn {
                width: 100%;
            }
            .order-details-box .row {
                flex-direction: column;
                text-align: center;
                gap: 0.3rem;
            }
            .footer-container {
                grid-template-columns: 1fr;
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <!-- ===== HEADER ===== -->
    <header class="header">
        <div class="header-container">
            <a href="/sokiva/" class="logo">SOKIVA <span>.</span></a>
            <span class="tagline">Access your desire.</span>
            
            <button class="hamburger" id="hamburger" aria-label="Toggle menu">
                <span></span>
                <span></span>
                <span></span>
            </button>
            
            <nav>
                <ul class="nav-menu" id="navMenu">
                    <li><a href="/sokiva/">Home</a></li>
                    <li><a href="/sokiva/shop.php">All Laptops</a></li>
                    <li><a href="/sokiva/contact.php">Contact</a></li>
                    <li>
                        <a href="/sokiva/cart.php" class="cart-icon">
                            <i class="fas fa-shopping-cart"></i>
                            <?php
                            $cart_count = isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0;
                            if ($cart_count > 0) {
                                echo '<span class="cart-badge">' . $cart_count . '</span>';
                            }
                            ?>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </header>
    
    <script>
        document.getElementById('hamburger').addEventListener('click', function() {
            document.getElementById('navMenu').classList.toggle('open');
        });
    </script>

    <!-- ===== SUCCESS CONTENT ===== -->
    <main class="container">
        <div class="success-container">
            <div class="success-card">
                <div class="icon">
                    <i class="fas fa-check-circle"></i>
                </div>
                
                <h1>Order Placed Successfully!</h1>
                
                <?php if ($order_id > 0): ?>
                <div class="order-id">
                    <i class="fas fa-hashtag"></i> Order #<?php echo $order_id; ?>
                </div>
                <?php endif; ?>
                
                <p>Thank you for your order! We'll contact you shortly via phone or WhatsApp.</p>
                
                <?php if ($order): ?>
                <div class="order-details-box">
                    <div class="row">
                        <span class="label">Order Status</span>
                        <span class="value">
                            <span class="status-badge status-<?php echo strtolower($order['order_status'] ?? 'pending'); ?>">
                                <?php echo ucfirst($order['order_status'] ?? 'Pending'); ?>
                            </span>
                        </span>
                    </div>
                    <div class="row">
                        <span class="label">Payment Method</span>
                        <span class="value"><?php echo str_replace('_', ' ', ucfirst($order['payment_method'])); ?></span>
                    </div>
                    <div class="row">
                        <span class="label">Delivery Address</span>
                        <span class="value"><?php echo htmlspecialchars($order['address']); ?></span>
                    </div>
                    <div class="row">
                        <span class="label">Total Amount</span>
                        <span class="value" style="font-size: 1.2rem; font-weight: 800;">KES <?php echo number_format($order['total']); ?></span>
                    </div>
                    <?php if (!empty($order_items)): ?>
                    <div style="margin-top: 0.8rem; padding-top: 0.8rem; border-top: 1px solid #e5e7eb;">
                        <span style="font-weight: 600; color: #1a1a1a;">Items Ordered:</span>
                        <?php foreach ($order_items as $item): ?>
                        <div style="display: flex; justify-content: space-between; padding: 0.2rem 0; font-size: 0.9rem;">
                            <span><?php echo htmlspecialchars($item['product_name']); ?> x<?php echo $item['quantity']; ?></span>
                            <span>KES <?php echo number_format($item['subtotal']); ?></span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
                
                <p style="font-size: 0.95rem; color: #6b7280; margin-top: 0.5rem;">
                    <i class="fas fa-phone"></i> We will call you within 24 hours to confirm your order.
                </p>
                
                <div class="actions">
                    <a href="/sokiva/shop.php" class="btn btn-primary">
                        <i class="fas fa-shopping-bag"></i> Continue Shopping
                    </a>
                    <a href="/sokiva/index.php" class="btn btn-secondary">
                        <i class="fas fa-home"></i> Go to Home
                    </a>
                    <a href="/sokiva/contact.php" class="btn btn-secondary">
                        <i class="fas fa-headset"></i> Contact Support
                    </a>
                </div>
            </div>
        </div>
    </main>

    <!-- ===== FOOTER ===== -->
    <footer class="footer">
        <div class="footer-container">
            <div>
                <div class="footer-logo">SOKIVA <span>.</span></div>
                <p style="margin-top: 0.3rem; color: #6b7280; font-size: 0.9rem;">Access your desire.</p>
            </div>
            <div>
                <h4>Quick Links</h4>
                <ul>
                    <li><a href="/sokiva/">Home</a></li>
                    <li><a href="/sokiva/shop.php">All Laptops</a></li>
                    <li><a href="/sokiva/contact.php">Contact</a></li>
                    <li><a href="/sokiva/about.php">About Us</a></li>
                </ul>
            </div>
            <div>
                <h4>Support</h4>
                <ul>
                    <li><a href="/sokiva/contact.php">Help Center</a></li>
                    <li><a href="/sokiva/privacy.php">Privacy Policy</a></li>
                    <li><a href="/sokiva/terms.php">Terms & Conditions</a></li>
                </ul>
            </div>
            <div>
                <h4>Connect With Us</h4>
                <ul>
                    <li><a href="https://wa.me/254793019606" target="_blank"><i class="fab fa-whatsapp"></i> WhatsApp</a></li>
                    <li><a href="#" target="_blank"><i class="fab fa-facebook"></i> Facebook</a></li>
                    <li><a href="#" target="_blank"><i class="fab fa-instagram"></i> Instagram</a></li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            &copy; <?php echo date('Y'); ?> SOKIVA. All rights reserved.
        </div>
    </footer>

    <!-- WhatsApp Float -->
    <a href="https://wa.me/254793019606?text=Hello%20Sokiva%2C%20I%20just%20placed%20an%20order%20%23<?php echo $order_id; ?>" 
       class="whatsapp-float" 
       target="_blank" 
       aria-label="Chat on WhatsApp">
        <i class="fab fa-whatsapp"></i>
    </a>
</body>
</html>