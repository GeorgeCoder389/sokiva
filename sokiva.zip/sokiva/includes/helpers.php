<?php
function slugify($text) {
    $text = strtolower(trim($text));
    $text = preg_replace('/[^a-z0-9]+/', '-', $text);
    return trim($text, '-');
}

function generate_unique_slug($pdo, $baseSlug, $excludeId = null) {
    $slug = $baseSlug;
    $i = 2;
    while (true) {
        $sql = "SELECT id FROM products WHERE slug = ?";
        $params = [$slug];
        if ($excludeId) {
            $sql .= " AND id != ?";
            $params[] = $excludeId;
        }
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        if (!$stmt->fetch()) break;
        $slug = $baseSlug . '-' . $i;
        $i++;
    }
    return $slug;
}
