<?php
session_start();

$host = "localhost";
$username = "root";
$password = "";
$database = "sokiva";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");
date_default_timezone_set('Africa/Nairobi');
?>