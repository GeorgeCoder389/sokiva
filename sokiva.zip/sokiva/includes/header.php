<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SOKIVA - <?php echo $page_title ?? 'Laptops Store'; ?></title>
    <link rel="stylesheet" href="/sokiva/assets/css/style.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <header class="site-header">
        <div class="container nav-inner">
            <div class="logo">
                <a href="/sokiva/index.php">SOKIVA</a>
            </div>
            <nav class="main-nav" id="mainNav">
                <a href="/sokiva/index.php">Home</a>
                <a href="/sokiva/shop.php">All Laptops</a>
                <a href="/sokiva/contact.php">Contact</a>
            </nav>
            <div class="nav-actions">
                <a href="/sokiva/cart.php" class="cart-link">
                    <i class="fas fa-shopping-cart"></i>
                    <span class="cart-badge"><?php echo isset($_SESSION['cart_count']) ? $_SESSION['cart_count'] : 0; ?></span>
                </a>
                <button class="nav-toggle" id="navToggle">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
        </div>
    </header>
    <main>