<?php

// =====================================================
// SOKIVA SHARED FUNCTIONS
// =====================================================

// Escape output safely for HTML
function e($value)
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}


// Format prices in Kenyan Shillings
function formatPrice($price)
{
    return 'KSh ' . number_format((float)$price, 0);
}


// Check whether a user is logged in as admin
function isAdminLoggedIn()
{
    return isset($_SESSION['admin_id']);
}


// Redirect to another page
function redirect($url)
{
    header("Location: " . $url);
    exit;
}

?>