<?php
$cartCount = cart_count();
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<header class="site-header">
    <div class="container nav-inner">
        <a href="<?= BASE_URL ?>/index.php" class="logo">SOKIVA</a>

        <nav class="main-nav" id="mainNav">
            <a href="<?= BASE_URL ?>/index.php" class="<?= $currentPage === 'index.php' ? 'active' : '' ?>">Home</a>
            <a href="<?= BASE_URL ?>/shop.php" class="<?= $currentPage === 'shop.php' ? 'active' : '' ?>">Shop</a>
            <a href="<?= BASE_URL ?>/about.php" class="<?= $currentPage === 'about.php' ? 'active' : '' ?>">About</a>
            <a href="<?= BASE_URL ?>/contact.php" class="<?= $currentPage === 'contact.php' ? 'active' : '' ?>">Contact</a>
        </nav>

        <div class="nav-actions">
            <a href="<?= BASE_URL ?>/cart.php" class="cart-link">
                Cart
                <?php if ($cartCount > 0): ?>
                    <span class="cart-badge"><?= $cartCount ?></span>
                <?php endif; ?>
            </a>
            <button class="nav-toggle" id="navToggle" aria-label="Toggle menu">&#9776;</button>
        </div>
    </div>
</header>