    <!-- ===== FOOTER ===== -->
    <footer class="footer">
        <div class="footer-container">
            <div>
                <div class="footer-logo">SOKIVA <span>.</span></div>
                <p style="margin-top: 0.3rem; color: #6b7280; font-size: 0.9rem;">Access your desire.</p>
                <p style="margin-top: 0.5rem; color: #9ca3af; font-size: 0.85rem;">
                    <i class="fas fa-map-marker-alt"></i> Nairobi, Kenya
                </p>
            </div>
            <div>
                <h4>Quick Links</h4>
                <ul>
                    <li><a href="/sokiva/">Home</a></li>
                    <li><a href="/sokiva/shop.php">All Laptops</a></li>
                    <li><a href="/sokiva/contact.php">Contact</a></li>
                    <li><a href="/sokiva/about.php">About Us</a></li>
                </ul>
            </div>
            <div>
                <h4>Support</h4>
                <ul>
                    <li><a href="/sokiva/contact.php">Help Center</a></li>
                    <li><a href="/sokiva/privacy.php">Privacy Policy</a></li>
                    <li><a href="/sokiva/terms.php">Terms & Conditions</a></li>
                </ul>
            </div>
            <div>
                <h4>Connect With Us</h4>
                <ul>
                    <li><a href="https://wa.me/254793019606" target="_blank"><i class="fab fa-whatsapp"></i> WhatsApp</a></li>
                    <li><a href="https://www.instagram.com/sokivagadgets/" target="_blank"><i class="fab fa-instagram"></i> Instagram</a></li>
                    <li><a href="https://www.tiktok.com/@sokivagadgets" target="_blank"><i class="fab fa-tiktok"></i> TikTok</a></li>
                    <li><a href="https://whatsapp.com/channel/0029VbCfNcUHgZWk5yLEC03x" target="_blank"><i class="fab fa-whatsapp"></i> WhatsApp Channel</a></li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            &copy; <?php echo date('Y'); ?> SOKIVA. All rights reserved.
        </div>
    </footer>
    
    <!-- WhatsApp Floating Button -->
    <a href="https://wa.me/254793019606?text=Hello%20Sokiva%2C%20I%20need%20help%20finding%20a%20laptop" 
       class="whatsapp-float" 
       target="_blank" 
       aria-label="Chat on WhatsApp">
        <i class="fab fa-whatsapp"></i>
    </a>
    
    <!-- ===== FOOTER SCRIPTS ===== -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</body>
</html>