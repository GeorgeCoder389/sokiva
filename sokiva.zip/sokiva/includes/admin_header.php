<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/admin_auth.php';
$pageTitle = $pageTitle ?? 'Admin — SOKIVA';
$currentAdminPage = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($pageTitle) ?></title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
</head>
<body class="admin-body">
<div class="admin-wrapper">
    <aside class="admin-sidebar">
        <div class="admin-logo">SOKIVA <span>Admin</span></div>
        <nav class="admin-nav">
            <a href="<?= BASE_URL ?>/admin/dashboard.php" class="<?= $currentAdminPage === 'dashboard.php' ? 'active' : '' ?>">Dashboard</a>
            <a href="<?= BASE_URL ?>/admin/products.php" class="<?= in_array($currentAdminPage, ['products.php','product_form.php']) ? 'active' : '' ?>">Products</a>
            <a href="<?= BASE_URL ?>/admin/orders.php" class="<?= in_array($currentAdminPage, ['orders.php','order_view.php']) ? 'active' : '' ?>">Orders</a>
            <a href="<?= BASE_URL ?>/admin/logout.php">Logout</a>
        </nav>
    </aside>
    <main class="admin-main">
        <div class="admin-topbar">Welcome, <?= htmlspecialchars($_SESSION['admin_username'] ?? 'Admin') ?></div>
        <div class="admin-content">