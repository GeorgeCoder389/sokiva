<?php

// =====================================================
// SOKIVA CART FUNCTIONS
// =====================================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


// Get the current shopping cart
function getCart()
{
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    return $_SESSION['cart'];
}


// Get number of products/items in cart
function getCartCount()
{
    $cart = getCart();

    $count = 0;

    foreach ($cart as $quantity) {
        $count += (int)$quantity;
    }

    return $count;
}


// Add product to cart
function addToCart($productId, $quantity = 1)
{
    $productId = (int)$productId;
    $quantity = (int)$quantity;

    if ($productId <= 0 || $quantity <= 0) {
        return false;
    }

    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    if (isset($_SESSION['cart'][$productId])) {
        $_SESSION['cart'][$productId] += $quantity;
    } else {
        $_SESSION['cart'][$productId] = $quantity;
    }

    return true;
}


// Update product quantity
function updateCartItem($productId, $quantity)
{
    $productId = (int)$productId;
    $quantity = (int)$quantity;

    if ($productId <= 0) {
        return false;
    }

    if ($quantity <= 0) {
        removeFromCart($productId);
        return true;
    }

    $_SESSION['cart'][$productId] = $quantity;

    return true;
}


// Remove product from cart
function removeFromCart($productId)
{
    $productId = (int)$productId;

    if (isset($_SESSION['cart'][$productId])) {
        unset($_SESSION['cart'][$productId]);
    }

    return true;
}


// Empty the entire cart
function clearCart()
{
    $_SESSION['cart'] = [];

    return true;
}

?>