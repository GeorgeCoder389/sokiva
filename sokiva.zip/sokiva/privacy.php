<?php
$page_title = 'Privacy Policy';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privacy Policy - SOKIVA</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Baloo 2', sans-serif;
            background: #ffffff;
            color: #1a1a1a;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 1.5rem;
        }
        
        .header {
            background: #ffffff;
            padding: 0.8rem 2rem;
            border-bottom: 1px solid #e5e7eb;
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        
        .header-container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        .logo {
            font-family: 'Baloo 2', sans-serif;
            font-weight: 800;
            font-size: 1.6rem;
            letter-spacing: 3px;
            color: #1a1a1a;
            text-transform: uppercase;
            text-decoration: none;
        }
        
        .logo span {
            color: #6b7280;
        }
        
        .tagline {
            color: #6b7280;
            font-size: 0.85rem;
            font-weight: 400;
            display: none;
        }
        
        @media (min-width: 768px) {
            .tagline {
                display: inline;
            }
        }
        
        .nav-menu {
            display: flex;
            align-items: center;
            gap: 2rem;
            list-style: none;
        }
        
        .nav-menu a {
            color: #333333;
            text-decoration: none;
            font-weight: 500;
            font-size: 1rem;
            transition: all 0.3s ease;
            position: relative;
        }
        
        .nav-menu a::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 0;
            height: 2px;
            background: #1a1a1a;
            transition: all 0.3s ease;
        }
        
        .nav-menu a:hover {
            color: #1a1a1a;
        }
        
        .nav-menu a:hover::after {
            width: 100%;
        }
        
        .nav-menu a.active {
            color: #1a1a1a;
            font-weight: 600;
        }
        
        .nav-menu a.active::after {
            width: 100%;
        }
        
        .hamburger {
            display: none;
            flex-direction: column;
            gap: 5px;
            cursor: pointer;
            background: none;
            border: none;
            padding: 0.3rem;
        }
        
        .hamburger span {
            width: 25px;
            height: 3px;
            background: #1a1a1a;
            border-radius: 3px;
            transition: all 0.3s ease;
        }
        
        @media (max-width: 768px) {
            .hamburger {
                display: flex;
            }
            .nav-menu {
                display: none;
                flex-direction: column;
                width: 100%;
                padding: 1rem 0;
                border-top: 1px solid #e5e7eb;
                gap: 0.8rem;
            }
            .nav-menu.open {
                display: flex;
            }
            .nav-menu a {
                font-size: 1.1rem;
                padding: 0.5rem 0;
            }
        }
        
        .hero {
            background: #f8f8f8;
            padding: 3rem 2rem;
            text-align: center;
            border-bottom: 1px solid #e5e7eb;
            margin-bottom: 2rem;
        }
        
        .hero h1 {
            font-size: 2.5rem;
            font-weight: 800;
            letter-spacing: 1px;
            margin-bottom: 0.5rem;
            color: #1a1a1a;
        }
        
        .hero p {
            font-size: 1.1rem;
            font-weight: 400;
            color: #6b7280;
            max-width: 600px;
            margin: 0 auto;
        }
        
        @media (max-width: 768px) {
            .hero h1 {
                font-size: 1.8rem;
            }
        }
        
        .content-wrapper {
            padding: 1rem 0 3rem;
        }
        
        .content-box {
            background: #ffffff;
            border-radius: 12px;
            padding: 2.5rem;
            border: 1px solid #e5e7eb;
            max-width: 800px;
            margin: 0 auto;
        }
        
        .content-box h2 {
            font-weight: 700;
            font-size: 1.3rem;
            color: #1a1a1a;
            margin-top: 1.5rem;
            margin-bottom: 0.8rem;
        }
        
        .content-box h2:first-child {
            margin-top: 0;
        }
        
        .content-box p {
            color: #6b7280;
            line-height: 1.8;
            margin-bottom: 1rem;
        }
        
        .content-box ul {
            color: #6b7280;
            line-height: 2;
            padding-left: 1.5rem;
            margin-bottom: 1.5rem;
        }
        
        .content-box ul li {
            margin-bottom: 0.3rem;
        }
        
        .content-box ul li a {
            color: #1a1a1a;
            text-decoration: none;
        }
        
        .content-box ul li a:hover {
            text-decoration: underline;
        }
        
        .content-box .highlight-box {
            background: #f8f8f8;
            padding: 1.5rem;
            border-radius: 8px;
            border-left: 4px solid #1a1a1a;
            margin: 1rem 0;
        }
        
        .content-box .highlight-box p {
            margin-bottom: 0;
        }
        
        .footer {
            background: #f8f8f8;
            padding: 2.5rem 2rem 1.5rem;
            margin-top: 2rem;
            border-top: 1px solid #e5e7eb;
        }
        
        .footer-container {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 2rem;
        }
        
        .footer h4 {
            font-weight: 700;
            font-size: 1rem;
            margin-bottom: 0.8rem;
            color: #1a1a1a;
        }
        
        .footer ul {
            list-style: none;
        }
        
        .footer ul li {
            margin-bottom: 0.4rem;
        }
        
        .footer ul a {
            color: #6b7280;
            text-decoration: none;
            transition: all 0.3s ease;
            font-size: 0.9rem;
        }
        
        .footer ul a:hover {
            color: #1a1a1a;
        }
        
        .footer-bottom {
            text-align: center;
            padding-top: 1.5rem;
            margin-top: 1.5rem;
            border-top: 1px solid #e5e7eb;
            color: #9ca3af;
            font-size: 0.85rem;
        }
        
        .footer-logo {
            font-weight: 800;
            font-size: 1.3rem;
            letter-spacing: 3px;
            text-transform: uppercase;
            color: #1a1a1a;
        }
        
        .footer-logo span {
            color: #6b7280;
        }
        
        .whatsapp-float {
            position: fixed;
            bottom: 30px;
            right: 30px;
            background: #25D366;
            color: white;
            width: 55px;
            height: 55px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            box-shadow: 0 4px 20px rgba(37, 211, 102, 0.3);
            transition: all 0.3s ease;
            z-index: 999;
            text-decoration: none;
        }
        
        .whatsapp-float:hover {
            transform: scale(1.1);
            box-shadow: 0 8px 30px rgba(37, 211, 102, 0.4);
        }
        
        @media (max-width: 576px) {
            .footer-container {
                grid-template-columns: 1fr;
                text-align: center;
            }
            .content-box {
                padding: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="header-container">
            <a href="/sokiva/" class="logo">SOKIVA <span>.</span></a>
            <span class="tagline">Access your desire.</span>
            <button class="hamburger" id="hamburger" aria-label="Toggle menu">
                <span></span>
                <span></span>
                <span></span>
            </button>
            <nav>
                <ul class="nav-menu" id="navMenu">
                    <li><a href="/sokiva/">Home</a></li>
                    <li><a href="/sokiva/shop.php">All Laptops</a></li>
                    <li><a href="/sokiva/contact.php">Contact</a></li>
                </ul>
            </nav>
        </div>
    </header>
    
    <script>
        document.getElementById('hamburger').addEventListener('click', function() {
            document.getElementById('navMenu').classList.toggle('open');
        });
    </script>

    <section class="hero">
        <div class="container">
            <h1>Privacy Policy</h1>
            <p>Your privacy matters to us. Learn how we handle your data.</p>
        </div>
    </section>

    <main class="container">
        <div class="content-wrapper">
            <div class="content-box">
                <h2>1. Introduction</h2>
                <p>At SOKIVA, we take your privacy seriously. This policy explains how we collect, use, and protect your personal information when you visit our website and use our services. By using our services, you agree to the collection and use of information in accordance with this policy.</p>
                
                <h2>2. Information We Collect</h2>
                <p>We collect minimal information to provide you with the best experience:</p>
                <ul>
                    <li><strong>Cookies:</strong> We use cookies to help you find products you've browsed before. These cookies make your experience more personalized and convenient. Cookies are small text files stored on your device that help us remember your preferences.</li>
                    <li><strong>Contact Information:</strong> When you contact us through our contact form, we collect your name, email address, and the message you send to respond to your inquiry.</li>
                    <li><strong>Order Information:</strong> When you place an order, we collect your name, email, phone number, and delivery address to process and deliver your order.</li>
                </ul>
                
                <div class="highlight-box">
                    <p><strong>📌 Note:</strong> We do not collect sensitive personal information such as financial details, passwords, or identification numbers unless explicitly provided by you for order purposes.</p>
                </div>
                
                <h2>3. How We Use Your Information</h2>
                <p>We use your information solely for the following purposes:</p>
                <ul>
                    <li>To help you find relevant products you've browsed before</li>
                    <li>To respond to your inquiries and provide customer support</li>
                    <li>To process and deliver your orders</li>
                    <li>To improve our website and services based on user feedback</li>
                    <li>To send order confirmations and updates about your purchases</li>
                </ul>
                
                <h2>4. Data Storage & Security</h2>
                <p>Your privacy and security are our top priorities. Here's how we protect your data:</p>
                <ul>
                    <li><strong>No Permanent Storage:</strong> We do not store your personal data permanently on our servers. Any data collected is used only for the purpose it was collected for.</li>
                    <li><strong>No Data Selling:</strong> We never sell, trade, or rent your personal information to third parties.</li>
                    <li><strong>No Data Sharing:</strong> Your information is not shared with third parties unless required by law or necessary to fulfill your order (e.g., delivery companies).</li>
                    <li><strong>Security Measures:</strong> We use industry-standard security measures to protect your information from unauthorized access, disclosure, or alteration.</li>
                </ul>
                
                <h2>5. Your Privacy Rights</h2>
                <p>As a user of SOKIVA, you have the following rights:</p>
                <ul>
                    <li><strong>No Permanent Storage:</strong> Your data is not stored permanently on our servers</li>
                    <li><strong>No Data Selling:</strong> We never sell or trade your personal information</li>
                    <li><strong>No Data Sharing:</strong> Your information is not shared with third parties</li>
                    <li><strong>Cookie Control:</strong> You can control cookies through your browser settings at any time</li>
                    <li><strong>Access Request:</strong> You can request to see what data we have about you</li>
                    <li><strong>Deletion Request:</strong> You can request to have your data deleted</li>
                </ul>
                
                <h2>6. Cookies</h2>
                <p>We use cookies solely to enhance your browsing experience by showing you products you've viewed before. These cookies do not collect personal information and are only used to make your shopping experience more relevant and convenient.</p>
                <p>You can control cookie settings through your browser preferences. Most browsers allow you to refuse cookies or delete them at any time.</p>
                
                <h2>7. Third-Party Links</h2>
                <p>Our website may contain links to third-party websites. Please note that we are not responsible for the privacy practices of such other sites. We encourage you to read the privacy statements of each website that collects personally identifiable information.</p>
                
                <h2>8. Changes to This Policy</h2>
                <p>We may update this Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page. The date at the top of this page indicates when it was last updated.</p>
                
                <h2>9. Contact Us</h2>
                <p>If you have any questions about this privacy policy, please contact us:</p>
                <ul>
                    <li><strong>Email:</strong> sokivagadg@gmail.com</li>
                    <li><strong>Phone:</strong> 0793019606</li>
                    <li><strong>WhatsApp:</strong> 0793019606</li>
                    <li><strong>Instagram:</strong> <a href="https://www.instagram.com/sokivagadgets/" target="_blank">@sokivagadgets</a></li>
                    <li><strong>TikTok:</strong> <a href="https://www.tiktok.com/@sokivagadgets" target="_blank">@sokivagadgets</a></li>
                    <li><strong>Visit:</strong> Nairobi, Kenya</li>
                </ul>
            </div>
        </div>
    </main>

    <footer class="footer">
        <div class="footer-container">
            <div>
                <div class="footer-logo">SOKIVA <span>.</span></div>
                <p style="margin-top: 0.3rem; color: #6b7280; font-size: 0.9rem;">Access your desire.</p>
            </div>
            <div>
                <h4>Quick Links</h4>
                <ul>
                    <li><a href="/sokiva/">Home</a></li>
                    <li><a href="/sokiva/shop.php">All Laptops</a></li>
                    <li><a href="/sokiva/contact.php">Contact</a></li>
                    <li><a href="/sokiva/about.php">About Us</a></li>
                </ul>
            </div>
            <div>
                <h4>Support</h4>
                <ul>
                    <li><a href="/sokiva/contact.php">Help Center</a></li>
                    <li><a href="/sokiva/privacy.php">Privacy Policy</a></li>
                    <li><a href="/sokiva/terms.php">Terms & Conditions</a></li>
                </ul>
            </div>
            <div>
                <h4>Connect With Us</h4>
                <ul>
                    <li><a href="https://wa.me/254793019606" target="_blank"><i class="fab fa-whatsapp"></i> WhatsApp</a></li>
                    <li><a href="https://www.instagram.com/sokivagadgets/" target="_blank"><i class="fab fa-instagram"></i> Instagram</a></li>
                    <li><a href="https://www.tiktok.com/@sokivagadgets" target="_blank"><i class="fab fa-tiktok"></i> TikTok</a></li>
                    <li><a href="https://whatsapp.com/channel/0029VbCfNcUHgZWk5yLEC03x" target="_blank"><i class="fab fa-whatsapp"></i> WhatsApp Channel</a></li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            &copy; <?php echo date('Y'); ?> SOKIVA. All rights reserved.
        </div>
    </footer>

    <a href="https://wa.me/254793019606?text=Hello%20Sokiva%2C%20I%20need%20help" 
       class="whatsapp-float" 
       target="_blank" 
       aria-label="Chat on WhatsApp">
        <i class="fab fa-whatsapp"></i>
    </a>
</body>
</html>