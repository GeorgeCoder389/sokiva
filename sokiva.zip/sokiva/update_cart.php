<?php
$page_title = 'Shopping Cart';
include 'includes/header.php';
include 'config.php';

// Initialize cart if not exists
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

$cart_items = [];
$total = 0;

if (!empty($_SESSION['cart'])) {
    $ids = array_keys($_SESSION['cart']);
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $conn->prepare("SELECT * FROM products WHERE id IN ($placeholders)");
    $stmt->execute($ids);
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($products as $product) {
        $qty = $_SESSION['cart'][$product['id']];
        $subtotal = $product['price'] * $qty;
        $cart_items[] = [
            'product' => $product,
            'qty' => $qty,
            'subtotal' => $subtotal
        ];
        $total += $subtotal;
    }
}
?>

<!-- ===== CART PAGE ===== -->
<main class="container" style="padding: 2rem 1.5rem 3rem;">
    <h1 class="section-title">Your <span style="color: var(--primary);">Cart</span></h1>
    
    <?php if (empty($cart_items)): ?>
    <div class="card text-center" style="padding: 3rem; max-width: 600px; margin: 0 auto;">
        <i class="fas fa-shopping-cart" style="font-size: 4rem; color: var(--primary-accent); margin-bottom: 1rem;"></i>
        <h3 style="font-weight: 700;">Your cart is empty</h3>
        <p style="color: var(--text-light);">Browse our laptops and add your favorites!</p>
        <a href="shop.php" class="btn btn-primary" style="margin-top: 1rem;">Start Shopping</a>
    </div>
    <?php else: ?>
    <div style="max-width: 900px; margin: 0 auto;">
        <?php foreach ($cart_items as $item): ?>
        <div class="card" style="margin-bottom: 1rem; padding: 1.5rem;">
            <div style="display: grid; grid-template-columns: auto 1fr auto; gap: 1.5rem; align-items: center;">
                <div style="background: var(--bg-light); width: 80px; height: 80px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 2rem; color: var(--primary);">
                    <i class="fas fa-laptop"></i>
                </div>
                <div>
                    <h4 style="font-weight: 600;"><?php echo htmlspecialchars($item['product']['name']); ?></h4>
                    <p style="color: var(--text-light); font-size: 0.9rem;"><?php echo htmlspecialchars($item['product']['specs']); ?></p>
                    <div style="font-weight: 700; color: var(--primary);">
                        <?php echo CURRENCY; ?> <?php echo number_format($item['product']['price']); ?>
                    </div>
                </div>
                <div style="text-align: right;">
                    <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.5rem;">
                        <button onclick="updateCart(<?php echo $item['product']['id']; ?>, -1)" class="btn btn-secondary" style="padding: 0.3rem 0.8rem;">-</button>
                        <span style="font-weight: 600; font-size: 1.1rem;"><?php echo $item['qty']; ?></span>
                        <button onclick="updateCart(<?php echo $item['product']['id']; ?>, 1)" class="btn btn-secondary" style="padding: 0.3rem 0.8rem;">+</button>
                    </div>
                    <div style="font-weight: 700; font-size: 1.1rem; color: var(--primary-dark);">
                        <?php echo CURRENCY; ?> <?php echo number_format($item['subtotal']); ?>
                    </div>
                    <button onclick="removeFromCart(<?php echo $item['product']['id']; ?>)" style="background: none; border: none; color: #ef4444; cursor: pointer; font-size: 0.85rem; margin-top: 0.3rem;">
                        <i class="fas fa-trash"></i> Remove
                    </button>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
        
        <!-- Cart Summary -->
        <div class="card" style="padding: 2rem; margin-top: 2rem; background: linear-gradient(135deg, var(--bg-light), var(--white));">
            <div style="display: flex; justify-content: space-between; font-size: 1.2rem; margin-bottom: 1rem;">
                <span style="font-weight: 600;">Total:</span>
                <span style="font-weight: 800; font-size: 1.8rem; color: var(--primary);">
                    <?php echo CURRENCY; ?> <?php echo number_format($total); ?>
                </span>
            </div>
            <div style="display: flex; gap: 1rem; flex-wrap: wrap;">
                <a href="checkout.php" class="btn btn-primary" style="flex: 1;">
                    <i class="fas fa-credit-card"></i> Proceed to Checkout
                </a>
                <a href="shop.php" class="btn btn-secondary" style="flex: 1;">Continue Shopping</a>
            </div>
        </div>
    </div>
    <?php endif; ?>
</main>

<script>
function updateCart(productId, change) {
    $.ajax({
        url: '<?php echo SITE_URL; ?>update_cart.php',
        type: 'POST',
        data: { product_id: productId, change: change },
        success: function() {
            location.reload();
        }
    });
}

function removeFromCart(productId) {
    if (confirm('Remove this item from cart?')) {
        $.ajax({
            url: '<?php echo SITE_URL; ?>remove_from_cart.php',
            type: 'POST',
            data: { product_id: productId },
            success: function() {
                location.reload();
            }
        });
    }
}
</script>

<?php include 'includes/footer.php'; ?>