<?php
require_once '../includes/db_connect.php';

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    if ($username && $password) {
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO admin_users (username, password) VALUES (?, ?)");
        $stmt->execute([$username, $hashed]);
        $message = "Admin account '$username' created successfully. DELETE THIS FILE NOW.";
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Create Admin - One Time Setup</title></head>
<body style="font-family: sans-serif; max-width: 400px; margin: 60px auto;">
    <h2>Create Admin Account</h2>
    <?php if ($message): ?>
        <p style="color: green; font-weight: bold;"><?= htmlspecialchars($message) ?></p>
    <?php endif; ?>
    <form method="POST">
        <label>Username:</label><br>
        <input type="text" name="username" required style="width:100%; padding:8px; margin:8px 0;"><br>
        <label>Password:</label><br>
        <input type="password" name="password" required style="width:100%; padding:8px; margin:8px 0;"><br>
        <button type="submit" style="padding:10px 20px;">Create Admin</button>
    </form>
</body>
</html>